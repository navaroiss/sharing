<?php
/**
 * $Id: Nov 4, 2009 10:40:48 PM navaro $
 * 
 */
 
/**
 * Class dashboard
  * @author navaro
 *
 * The first class will be called
 */
class dashboard extends Controller
{
	/**
	 * Redirect to indexing page
	 * 
	 * @return 
	 */
	function index()
	{
		redirect('report/indexing');
	}
	
	/**
	 * The method to show default page.
	 * 
	 * @return unknown_type
	 */
	function indexing()
	{
		$this->load->view('dashboard-indexing',array(
			'username'=>$this->session->userdata('uname'),
			'user_group'=>$this->session->userdata('_login'),
		));
	}
}