<?php

/**
 * $Id: Sep 16, 2009 7:16:49 PM navaro $
 * 
 */
 
class xmlparam extends Model
{
	var $table = "pm_params";
	var $limit = 0;
	var $offset = 0;
	
	function xmlparam()
	{
		parent::Model();
		$this->load->database();
	}
	
	/*
	 * Count all records
	 */
	function count_all()
	{
		return $this->db->count_all($this->table);
	}
	
	/*
	 * Retrive some rows
	 * 
	 * @param $page int
	 * @param $per_page int
	 * @param $order_by int
	 */
	function get_rows($page, $per_page, $order_by = array())
	{
		if(count($order_by)>=1)
		{
			foreach($order_by as $k=>$v)
			{	
				$this->db->order_by($k, $v);
			}
		}else{
			$this->db->order_by('datetime', 'desc');
		}
		$this->db->limit($per_page, $page);
		$query = $this->db->get( $this->table ); 
		
		//echo $this->db->last_query();
		return $query->result();
	}
	
	/*
	 * Insert data as an object to database
	 * 
	 * @param $object object/array
	 */
	function insertObj($object)
	{
		return $this->db->insert($this->table, $object);
	}
	
	/**
	 * Delete a row
	 * 
	 * @param $id
	 * @return unknown_type
	 */
	function delete($id)
	{
		return $this->db->query("delete from ".$this->table." where id = $id");
	}
	
	/**
	 * Delete more rows
	 * 
	 * @param $ids
	 * @return unknown_type
	 */
	function delete_more($ids)
	{
		return $this->db->query("delete from ".$this->table." where id in (".implode(',', $ids).")");
		//echo "delete from ".$this->table." where id in (".implode(',', $ids).")";
	}
	
	/**
	 * Update data
	 * 
	 * @param $id
	 * @param $data
	 * @return unknown_type
	 */
	function updateRow($id, $data=array())
	{
		$this->db->where('id', $id);
		$this->db->update($this->table, $data); 		
	}
	
	/**
	 * Get data from an id 
	 * 
	 * @param $id
	 * @return unknown_type
	 */
	function get_row($id)
	{
		$query = $this->db->query("select * from ".$this->table." where `id` = ".$id);
		return $query->result();
	}
	
	function get($f=array(), $c=array())
	{
		if(count($f)>=1)
			$this->db->select(implode(',', $f));
		if(count($c)>=1){
			$query = $this->db->get_where($this->table, $c, $this->limit, $this->offset);
		}else{
			$query = $this->db->get($this->table);
		}
		return $query->result();
	}
}