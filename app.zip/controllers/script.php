<?php
 
/**
 * $Id: Nov 6, 2009 4:35:10 PM navaro $
 *
 */
 
class script extends Controller
{
	function script()
	{
		parent::Controller();
		$this->load->model('xmlparam');
		$this->load->helpers(array(
			'excel', 'export', 'other'
		));
	}
	
	function index()
	{
		if(!$this->auth->session_checking('_login'))
		{
			redirect('/user/login/');
		}
		redirect('script/delete');
	}
	
	function delete()
	{
		if(!$this->auth->session_checking('_login'))
		{
			redirect('/user/login/');
		}else
		{
			if($this->session->userdata('_login')!=1) // # admin
			{
				redirect('/store/showing/');	
			}
		}
		$row_id = $this->uri->segment(3);
		$extra_data = array();
		$params_form = array();
		
		$row = $this->xmlparam->get_row($row_id);
		$deleted_success = 0;
		$sqlquery = strtolower($row[0]->sql);
		$i=1;
		
		if(preg_match_all("/param\.(\d+)/", $sqlquery, $match))
		{
			if($row[0]->fields!="")
			{
				foreach( explode(';', $row[0]->fields) as $k=>$v)
				{
					$a = explode("=", $v);
					$b = explode(".",$a[0]);
					$param = $this->input->post("param");
					$params_form[$a[0]] = input_value(explode(".", $a[1]), $a[0], $param[$b[1]]);
				}
			}else{
				redirect('store/update/'.$row_id);
			}
		}

		if(count($_POST)>=1){
			if("Delete"==$this->input->post('delete'))
			{
				if(preg_match_all("/param\.(\d+)/", $row[0]->sql, $match))
				{
					if(isset($_POST['param']))
					{
						$params = $_POST['param'];
						foreach(explode(';', $row[0]->fields) as $k=>$v)
						{
							$a = explode('=', $v);
							$b = explode('.', $a[1]);
							$_where[] = $b[1]." = '".$params[$i]."'";
							$i++;	
						}
						
						$findme   = 'where';
						$pos = strpos($sqlquery, $findme);
						$_s = substr($sqlquery, 0, $pos+strlen($findme));
						$sqlquery = $_s." ".implode(" and ", $_where);
					}
				}
				
				if($this->db->query($sqlquery))
				{
					$deleted_success = 1;
				}
				
			}
			
		}
		
		
		$extra_data = array(
			'params' => $params_form,
			'deleted_success'=>$deleted_success
		);
		
		$this->load->view('script-delete',
			array_merge(
				array(
						'username'=>$this->session->userdata('uname'),
						'user_group'=>$this->session->userdata('_login')
				), 
				$extra_data
			)
		);
	}

	function update()
	{
		if(!$this->auth->session_checking('_login'))
		{
			redirect('/user/login/');
		}else
		{
			if($this->session->userdata('_login')!=1) // # admin
			{
				redirect('/store/showing/');	
			}
		}
		$row_id = $this->uri->segment(3);
		$extra_data = array();
		$params_form = array();
		
		$row = $this->xmlparam->get_row($row_id);
		if(preg_match_all("/param\.(\d+)/", strtolower($row[0]->sql), $match))
		{
			if($row[0]->fields!="")
			{
				foreach( explode(';', $row[0]->fields) as $k=>$v)
				{
					$a = explode("=", $v);
					$b = explode(".",$a[0]);
					$param = $this->input->post("param");
					$params_form[$a[0]] = input_value(explode(".", $a[1]), $a[0], $param[$b[1]]);
				}
			}else{
				redirect('store/update/'.$row_id);
			}
		}
		
		if(preg_match('/update (\w+)/', strtolower($row[0]->sql), $match))
		{
			$table_name = $match[1];
		}
		
		$sqlquery = strtolower($row[0]->sql);
		$i=1;
		$update_success = 0;
			
		if(count($_POST)>=1)
		{
			if(count($_POST['vars']>=1))
			{
				$set_var = array();
				foreach($_POST['vars'] as $k=>$v)
				{
					$set_var[] = "$k='$v'";		
				}
			}
			
			if(preg_match_all("/param\.(\d+)/", strtolower($row[0]->sql), $match))
			{
				if(isset($_POST['param']))
				{
					$params = $_POST['param'];
					foreach(explode(';', $row[0]->fields) as $k=>$v)
					{
						$a = explode('=', $v);
						$b = explode('.', $a[1]);
						$_where[] = $b[1]." = '".$params[$i]."'";
						$i++;	
					}
				}
				$findme   = 'where';
				$pos = strpos($sqlquery, $findme);
				$_s = substr($sqlquery, 0, $pos+strlen($findme));
				$sqlquery = $_s." ".implode(" and ", $_where);
			}

			$sqlquery = sprintf($sqlquery, implode(', ', $set_var));
			
			if($this->db->query($sqlquery))
			{
				$update_success = 1;
			}
			
		}
		
		$extra_data = array(
			'form_fields' => getTableFields($table_name),
			'params' => $params_form,
			'update_success'=>$update_success
		);

		$this->load->view('script-update',
			array_merge(
				array(
						'username'=>$this->session->userdata('uname'),
						'user_group'=>$this->session->userdata('_login')
				), 
				$extra_data
			)
		);
	}
}
 