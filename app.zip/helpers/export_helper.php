<?php
 
/**
 * $Id: Nov 5, 2009 10:11:45 AM navaro $
 *
 */

/**
 * The database has many records we need more times to query
 */
ini_set('memory_limit','1024M');
ini_set('max_execution_time','600');

/**
 * Export data 
 * 
 * @param object $xml_data A row from pm_params table
 * @param array $values $_POST
 * @return array filename and how many rows
 */
function normal_export($xml_data, $values)
{
	$filename=str_replace(" ","_", $xml_data->title);
	$filename=str_replace(",","_", $filename);
	$export_file = export_as($xml_data->sql, $values, $filename."_".date("YmdHis"));
	return $export_file;
}

/**
 * 	GENERAL REPORT
 * 
 * @param string $query
 * @param string $filename
 * @param string $ext
 * @return array
 */
function general_report($query, $filename = "", $ext = '.xlsx')
{
	/**
	 * Include important class
	 * Class PHPExcel provides the API to create an excel
	 */
	require_once FCPATH.'includes/Classes/PHPExcel.php';
	require_once FCPATH.'includes/Classes/PHPExcel/IOFactory.php';
	
	/**
	 * Initial PHPExcel object
	 * @var $objPHPExcel
	 */
	$objPHPExcel = new PHPExcel();

	/**
	 * Get user's selection from $_POST
	 * @var $camp_id
	 * @var $camp_type
	 */
	$camp_id=$_POST['param'][1];//"CA00002_05HCB1"
	$camp_type=$_POST['param'][2];//0
	
	/**
	 * File name
	 * @var $filename
	 */
	$filename = $camp_id."_".date("YmdHis");
	
	/**
	 * Datatabase object
	 * @var unknown_type
	 */
	$db = $GLOBALS['CI']->db;
	
	$sql[0]="SELECT * FROM campagnes WHERE camp_id='$camp_id' AND camp_type='$camp_type'"; //
	$sql[1]="select * from fiche_data where fd_fiche_id = '%s' order by fd_qord"; // cau hoi
	$sql[2]="SELECT * FROM annuaires WHERE cont_camp_id='$camp_id' AND cont_camp_type=$camp_type ORDER BY cont_nom, cont_prenom";
	$sql[3]="SELECT r_q_num,r_ans FROM reponses WHERE r_camp_id='$camp_id' AND r_camp_type='$camp_type' AND r_cont_id='%d' ORDER BY r_q_num";
	for($i=0;$i<=count($sql)-1;$i++)
	{
		if($i==0)
		{
			$q = $db->query($sql[$i]);
			$result[$i] = $q->result();
		}
	}

	/**
	 * Title of the column
	 * @var $excel_fields
	 */
    $excel_fields = array(
    		"CPGid_Annu",
    		"CId_3CM",
			"Spécialité",
			"Fonction",
			"Type Exercice",
			"Civilité",
			"Nom",
			"Prénom",
			"Adresse 1",
			"Adresse 2",
			"Adresse 3",
			"Adresse 4",
			"BP",
			"Lieudit",
			"CP",
			"Ville",
			"Pays",
			"Téléphone",
			"Télecopie",
			"Mobile",
			"Email",
			"Statut appel",
			"Origine réponse",
    		"DateRéponse",
    		"RelancerProgrammée",
    		"NbAppels",
    		"RAZ computers",
    		"Opérateurs",
    		"CommentairesAppel",
    		"QUESTION/RESPONSE1"
    );
	
    /**
     * If the query $sql[0] return a result we write the camp_id and com_descr on first row in excel file
     * else return false
     */
    if(isset($result[0][0]))
    {
	    $campagnes = $result[0][0];
	    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B2', "({$campagnes->camp_id}) {$campagnes->camp_descr}");
    }else{
    	return false;
    }
    
    /**
     * Write the date
     */
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B3', date('Y/m/d H:i:s'));
    
    /**
     * Format the rows on top of the excel
     */
	$objPHPExcel->setActiveSheetIndex(0)->getStyle("B2:B3")->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_DARKGREEN ) );
    $objPHPExcel->setActiveSheetIndex(0)->getStyle("B2:B3")->getFont()->setBold(true);
    
    /**
     * Start to write data from 5th row
     * @var $i
     */
    $i=5;
    $x = 0;
    
    /**
     * Write title and format
     */
	for($x=0;$x<=count($excel_fields)-1;$x++)
	{
    	$objPHPExcel->setActiveSheetIndex(0)->setCellValue(PHPExcel_Cell::stringFromColumnIndex($x)."$i", $excel_fields[$x]);
		$objPHPExcel->getActiveSheet()->getStyle(PHPExcel_Cell::stringFromColumnIndex($x)."$i")->applyFromArray(
				array(
					'font'    => array(
						'bold'      => true
					),
					'alignment' => array(
						'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
					),
					'borders' => array(
						'top'     => array(
		 					'style' => PHPExcel_Style_Border::BORDER_THIN
		 				)
					),
					'fill' => array(
			 			'type'       => PHPExcel_Style_Fill::FILL_GRADIENT_LINEAR,
			  			'rotation'   => 90,
			 			'startcolor' => array(
			 				'argb' => 'FFA0A0A0'
			 			),
			 			'endcolor'   => array(
			 				'argb' => 'FFFFFFFF'
			 			)
			 		)
				)
		);			
	}
	
	if(preg_match("/(.*?) from |(.*?) FROM /", $query, $match))
	{
		$query_count = str_replace($match[0], "SELECT count(*) as total FROM ", $query);
	}

	$rs = $db->query($query_count);
	$tmp=$rs->result();
	$total=$tmp[0]->total;
	$d=10;
	$start = 0;
	$limit = $d;
	$exit=0;
	$i=7;
    
	
	for($ii=0;$ii<=$total;)
	{
		if($ii>0){
			if($ii+$d<=$total)
			{
				$start=$ii;
				$limit=$d;
			}elseif($ii+$d==$total){
				echo "=";
			}else{
				$start=$ii;
				$limit=$total-$ii;
			}
		}
		$q = $query." limit $start, $limit";
		$rs = $db->query($q);
		foreach($rs->result() as $k=>$v)
		{
			$ans = array();
			$_s = sprintf($sql[3], $v->cont_id);
			$answer = $db->query($_s);
			foreach($answer->result() as $k=>$v2)
			{
				if($v2->r_ans=="OUI")
				{
					$ans[]=1;
				}else if($v2->r_ans=="NON"){
					$ans[]=0;
				}else if($v2->r_ans=="NSP"){
					$ans[]="";
				}else{
					$ans[]="$v2->r_ans";
				}
			}
			
			$q1 = $db->query("select Libelle from lst_exercise where ExerciseId = ".$v->cont_exercise);
			$tpexerid = $q1->result(); 
			
			$q2 = $db->query("select Libelle from lst_callstatus where CallStatusId = ".$v->cont_callstatus);
			$statutappel = $q2->result();
			  
			$q3 = $db->query("select Libelle from lst_orirep where OriRepId = ".$v->cont_orirep);
			$origineReponse = $q3->result();
			
			$lastcall=date("d.m.y", strtotime($v->cont_lastcall));
			$modified=date("d/m/y", strtotime($v->cont_modified));
			$row = array_merge(array(
				$v->cont_camp_id,
				'CId_3CMD',
				RevertString($v->cont_specialite),
				RevertString($v->cont_fonction),
				RevertString(isset($tpexerid[0]->Libelle)?$tpexerid[0]->Libelle:''),
				RevertString($v->cont_civilite),
				RevertString($v->cont_nom),
				RevertString($v->cont_prenom),
				RevertString($v->cont_addr1),
				RevertString($v->cont_addr2),
				RevertString($v->cont_addr3),
				RevertString($v->cont_addr4),
				$v->cont_bp,
				RevertString($v->cont_lieudit),
				$v->cont_cp,
				RevertString($v->cont_ville),
				RevertString($v->cont_pays),
				$v->cont_telephone,
				$v->cont_telecopie,
				$v->cont_mobile,
				$v->cont_email,
				isset($statutappel[0]->Libelle)?$statutappel[0]->Libelle:'',
				isset($origineReponse[0]->Libelle)?$origineReponse[0]->Libelle:'',
				'DatéRéponse',
				$v->cont_relancer,
				$v->Cont_NbAppels,
				$v->cont_RAZ_Counter_Completed,
				'Opérateurs',
				RevertString($v->cont_commentaires),
			), $ans);

			/**
			 * Format rows
			 */
			for($x=0;$x<=count($row)-1;$x++)
			{
    			$objPHPExcel->setActiveSheetIndex(0)->setCellValue(PHPExcel_Cell::stringFromColumnIndex($x)."$i", $row[$x]);
				$objPHPExcel->setActiveSheetIndex(0)->getStyle(PHPExcel_Cell::stringFromColumnIndex($x)."$i")->applyFromArray(
					array(
						'borders' => array(
							'top'     => array(
			 					'style' => PHPExcel_Style_Border::BORDER_THIN
			 				),
							'bottom' => array(
			 					'style' => PHPExcel_Style_Border::BORDER_THIN
			 				),
							'left'     => array(
			 					'style' => PHPExcel_Style_Border::BORDER_THIN
			 				),
							'right'     => array(
			 					'style' => PHPExcel_Style_Border::BORDER_THIN
			 				)
			 			),
						'fill' => array(
				 			'type'       => PHPExcel_Style_Fill::FILL_GRADIENT_LINEAR,
				  			'rotation'   => 90,
				 			'startcolor' => array(
				 				'argb' => 'FFACF3C9'
				 			),
				 			'endcolor'   => array(
				 				'argb' => 'FFFFFFFF'
				 			)
				 		)
					)
				);
			}
			$i++;
		}
		$ii=$ii+$d;
	}	
	
	/**
	 * Setting auto filter
	 */
	if(isset($x) && $x>=1)
	{
		$objPHPExcel->getActiveSheet()->setAutoFilter("A5:".PHPExcel_Cell::stringFromColumnIndex($x).$i);	
	}
	
	$objPHPExcel->getActiveSheet()->setTitle('BDD Phoning manager');		
	$objPHPExcel->setActiveSheetIndex(0);
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	$objWriter->save(FCPATH."reports/$filename$ext");
	return array("$filename$ext", $i-7); // start from 5th row and 2 empty row
	
}

/**
 * 	GENERAL REPORT
 * 
 * @param $query
 * @param $filename
 * @param $ext
 * @return unknown_type
 */
function annureport($query, $filename = "", $ext = '.xlsx')
{
	require_once FCPATH.'includes/Classes/PHPExcel.php';
	require_once FCPATH.'includes/Classes/PHPExcel/IOFactory.php';
	$objPHPExcel = new PHPExcel();

	$camp_id=$_POST['param'][1];//"CA00002_05HCB1"
	$camp_type=$_POST['param'][2];//0
	
	$filename = $camp_id."_".date("YmdHis");
	
	$sql1="SELECT * FROM campagnes WHERE camp_id='$camp_id' AND camp_type='$camp_type'"; //
	$sql2="select * from fiche_data where fd_fiche_id = '%s' order by fd_qord"; // cau hoi
	$sql3="SELECT * FROM annuaires WHERE cont_camp_id='$camp_id' AND cont_camp_type=$camp_type ORDER BY cont_nom, cont_prenom";
	$sql4="SELECT r_q_num,r_ans FROM reponses WHERE r_camp_id='$camp_id' AND r_camp_type='$camp_type' AND r_cont_id='%d' ORDER BY r_q_num";
	
	$db = $GLOBALS['CI']->db;
	$query1=$db->query($sql1);
	$result1=$query1->result();
	
	$i=1;
	
	if(isset($result1[0]->camp_fiche_id))
	{
		$camp_fiche_id=$result1[0]->camp_fiche_id;
		$camp_name=$result1[0]->camp_descr;
		
		$query2=$db->query(sprintf($sql2, $camp_fiche_id));
		$question=array();
		foreach($query2->result() as $k=>$v)
		{
			$question[]=RevertString($v->fd_qfields);		
		}
		
	    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("A$i", $camp_name);$i++;
	    $objPHPExcel->setActiveSheetIndex(0)->setCellValue("A$i", date('m-d-Y H:i:s'));$i++;

		/*
	    $excel_fields = array(
					"ContactID",
					"ReunionId",
					"Statut appel",
					"Date DERNIER Appel",
					"Nombre Rappels Effectué",
					"Origine réponse",
					"Spécialité",
					"Fonction",
					"Type Exercice",
					"Civilité",
					"Nom",
					"Prénom",
					"Adresse 1",
					"Adresse 2",
					"Adresse 3",
					"Adresse 4",
					"BP",
					"Lieudit",
					"CP",
					"Ville",
					"Pays",
					"Téléphone",
					"Télecopie",
					"Email",
					"Mobile",
					"Commentaires/Autres",
					"Modification Fiche Medecin",
					);
		*/
	    $excel_fields = array(
	    		"CPGid_Annu",
	    		"CId_3CM",
				"Spécialité",
				"Fonction",
				"Type Exercice",
				"Civilité",
				"Nom",
				"Prénom",
				"Adresse 1",
				"Adresse 2",
				"Adresse 3",
				"Adresse 4",
				"BP",
				"Lieudit",
				"CP",
				"Ville",
				"Pays",
				"Téléphone",
				"Télecopie",
				"Mobile",
				"Email",
				"Statut appel",
				"Origine réponse",
	    		"DateRéponse",
	    		"RelancerProgrammée",
	    		"NbAppels",
	    		"RAZ computers",
	    		"Opérateurs",
	    		"CommentairesAppel",
	    		"QUESTION/RESPONSE1"
	    );
/*					"Spécialité",
					"Fonction",
					"Type Exercice",
					"Civilité",
					"Nom",
					"Prénom",
					"Adresse 1",
					"Adresse 2",
					"Adresse 3",
					"Adresse 4",
					"BP",
					"Lieudit",
					"CP",
					"Ville",
					"Pays",
					"Téléphone",
					"Télecopie",
					"Mobile",
					"Email",
					"Statut appel",
					"Origine réponse",
		"ContactID",
					"ReunionId",
					"Date DERNIER Appel",
					"Nombre Rappels Effectué",
					"Commentaires/Autres",
					"Modification Fiche Medecin"*/
		$i=3;
		for($x=0;$x<=count($excel_fields)-1;$x++)
		{
	    	$objPHPExcel->setActiveSheetIndex(0)->setCellValue(PHPExcel_Cell::stringFromColumnIndex($x)."$i", $excel_fields[$x]);
			$objPHPExcel->getActiveSheet()->getStyle(PHPExcel_Cell::stringFromColumnIndex($x)."$i")->applyFromArray(
					array(
						'font'    => array(
							'bold'      => true
						),
						'alignment' => array(
							'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
						),
						'borders' => array(
							'top'     => array(
			 					'style' => PHPExcel_Style_Border::BORDER_THIN
			 				)
						),
						'fill' => array(
				 			'type'       => PHPExcel_Style_Fill::FILL_GRADIENT_LINEAR,
				  			'rotation'   => 90,
				 			'startcolor' => array(
				 				'argb' => 'FFA0A0A0'
				 			),
				 			'endcolor'   => array(
				 				'argb' => 'FFFFFFFF'
				 			)
				 		)
					)
			);			
		}

		$query_count=preg_replace("/select (.*) from/", "SELECT count(*) as total FROM", strtolower($query));
		
		$rs = $GLOBALS['CI']->db->query($query_count);
		$tmp=$rs->result();
		$total=$tmp[0]->total;
		
		$d=10;
		$start = 0;
		$limit = $d;
		$exit=0;
		$i=5;
		
		for($ii=0;$ii<=$total;)
		{
			if($ii>0){
				if($ii+$d<=$total)
				{
					$start=$ii;
					$limit=$d;
				}elseif($ii+$d==$total){
					echo "=";
				}else{
					$start=$ii;
					$limit=$total-$ii;
				}
			}
			$q = $query." limit $start, $limit";
			$rs = $db->query($q);
			foreach($rs->result() as $k=>$v)
			{
				$sql=sprintf($sql4, $v->cont_id);
				//echo "$sql<br/>"; 
				$answer=$db->query($sql);
				$ans=array();
				foreach($answer->result() as $k=>$v2)
				{
					if($v2->r_ans=="OUI")
					{
						$ans[]=1;
					}else if($v2->r_ans=="NON"){
						$ans[]=0;
					}else if($v2->r_ans=="NSP"){
						$ans[]="";
					}else{
						$ans[]="$v2->r_ans";
					}
					//$ans[]=$v2->r_q_num;
					//$ans[]=$v2->r_ans;
				}
				
				$lastcall=date("d.m.y", strtotime($v->cont_lastcall));
				$modified=date("d/m/y", strtotime($v->cont_modified));
				$row = array_merge(array(
					$v->cont_id,
					$v->cont_camp_id,
					$v->cont_callstatus,
					$lastcall,
					$v->cont_counter,
					$v->cont_orirep,
					RevertString($v->cont_specialite),
					RevertString($v->cont_fonction),
					RevertString($v->cont_exercise),
					RevertString($v->cont_civilite),
					RevertString($v->cont_nom),
					RevertString($v->cont_prenom),
					RevertString($v->cont_addr1),
					RevertString($v->cont_addr2),
					RevertString($v->cont_addr3),
					RevertString($v->cont_addr4),
					$v->cont_bp,
					RevertString($v->cont_lieudit),
					$v->cont_cp,
					RevertString($v->cont_ville),
					RevertString($v->cont_pays),
					$v->cont_telephone,
					$v->cont_telecopie,
					$v->cont_email,
					$v->cont_mobile,
					RevertString($v->cont_commentaires),
					$modified
				), $ans);
				//print_r($row);die();

				for($x=0;$x<=count($row)-1;$x++)
				{
	    			$objPHPExcel->setActiveSheetIndex(0)->setCellValue(PHPExcel_Cell::stringFromColumnIndex($x)."$i", $row[$x]);
					$objPHPExcel->setActiveSheetIndex(0)->getStyle(PHPExcel_Cell::stringFromColumnIndex($x)."$i")->applyFromArray(
						array(
							'borders' => array(
								'top'     => array(
				 					'style' => PHPExcel_Style_Border::BORDER_THIN
				 				),
								'bottom' => array(
				 					'style' => PHPExcel_Style_Border::BORDER_THIN
				 				),
								'left'     => array(
				 					'style' => PHPExcel_Style_Border::BORDER_THIN
				 				),
								'right'     => array(
				 					'style' => PHPExcel_Style_Border::BORDER_THIN
				 				)
				 			),
							'fill' => array(
					 			'type'       => PHPExcel_Style_Fill::FILL_GRADIENT_LINEAR,
					  			'rotation'   => 90,
					 			'startcolor' => array(
					 				'argb' => 'FFACF3C9'
					 			),
					 			'endcolor'   => array(
					 				'argb' => 'FFFFFFFF'
					 			)
					 		)
						)
					);
				}
				$i++;
			}
			$ii=$ii+$d;
		}
	}
	
	if(isset($x) && $x>=1)
	{
		$objPHPExcel->getActiveSheet()->setAutoFilter("A3:".PHPExcel_Cell::stringFromColumnIndex($x).$i);	
	}
			
	$objPHPExcel->getActiveSheet()->setTitle('BDD Phoning manager');		
	$objPHPExcel->setActiveSheetIndex(0);
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	$objWriter->save(FCPATH."reports/$filename$ext");
	return array("$filename$ext", $i);
}

/*
function annureport($query, $filename="/tmp/data.xls")
{
	include_once(FCPATH.'includes/excelwriter/Worksheet.php');
	include_once(FCPATH.'includes/excelwriter/Workbook.php');
	    
	HeaderingExcel($filename);
	
	$workbook = new Workbook("-");
	
	$worksheet =& $workbook->add_worksheet('Phoning manager'); // worksheet 1
	  
	$format_title =& $workbook->add_format(); // Format for the headings
	$format_title->set_size(11);
	$format_title->set_align('center');
	$format_title->set_color('white');
	$format_title->set_pattern();
	$format_title->set_fg_color('green');
	$format_title->set_bold();
	
	$camp_id=$_POST['param'][1];//"CA00002_05HCB1"
	$camp_type=$_POST['param'][2];//0
	$sql1="SELECT * FROM campagnes WHERE camp_id='$camp_id' AND camp_type='$camp_type'"; //
	$sql2="select * from fiche_data where fd_fiche_id = '%s' order by fd_qord"; // cau hoi
	$sql3="SELECT * FROM annuaires WHERE cont_camp_id='$camp_id' AND cont_camp_type=$camp_type ORDER BY cont_nom, cont_prenom";
	$sql4="SELECT r_q_num,r_ans FROM reponses WHERE r_camp_id='$camp_id' AND r_camp_type='$camp_type' AND r_cont_id='%d' ORDER BY r_q_num";
	
	$db = $GLOBALS['CI']->db;
	$query1=$db->query($sql1);
	$result1=$query1->result();
	$i=1;
	
	if(isset($result1[0]->camp_fiche_id))
	{
		$camp_fiche_id=$result1[0]->camp_fiche_id;
		$camp_name=$result1[0]->camp_descr;
		
		$query2=$db->query(sprintf($sql2, $camp_fiche_id));
		$question=array();
		foreach($query2->result() as $k=>$v)
		{
			$question[]=RevertString($v->fd_qfields);		
		}
		
		$y=0; $x=0;
		$worksheet->write_string($y, $x, $camp_name); 
		$y=1; // i = 1, row = 1
		$excel_fields = array(
					"ContactID",
					"ReunionId",
					"Statut appel",
					"Date DERNIER Appel",
					"Nombre Rappels Effectué",
					"Origine réponse",
					"Spécialité",
					"Fonction",
					"Type Exercice",
					"Civilité",
					"Nom",
					"Prénom",
					"Adresse 1",
					"Adresse 2",
					"Adresse 3",
					"Adresse 4",
					"BP",
					"Lieudit",
					"CP",
					"Ville",
					"Pays",
					"Téléphone",
					"Télecopie",
					"Email",
					"Mobile",
					"Commentaires/Autres",
					"Modification Fiche Medecin"
				);
			$y=2;
			for(;$x<=count($excel_fields)-1;$x++)
			{
				$worksheet->write_string($y, $x, $excel_fields[$x], $format_title);	
			}

			$query_count=preg_replace("/select (.*) from/", "SELECT count(*) as total FROM", strtolower($query));
			
			$rs = $GLOBALS['CI']->db->query($query_count);
			$tmp=$rs->result();
			$total=$tmp[0]->total;
			
			$d=500;
			$start = 0;
			$limit = $d;
			$exit=0;
			
			for($ii=0;$ii<=$total;)
			{
				if($ii>0){
					if($ii+$d<=$total)
					{
						$start=$ii;
						$limit=$d;
					}elseif($ii+$d==$total){
						echo "=";
					}else{
						$start=$ii;
						$limit=$total-$ii;
					}
				}
				$q = $query." limit $start, $limit";
				$rs = $db->query($q);
				foreach($rs->result() as $k=>$v)
				{
					$sql=sprintf($sql4, $v->cont_id);
					//echo "$sql<br/>"; 
					$answer=$db->query($sql);
					$ans=array();
					foreach($answer->result() as $k=>$v2)
					{
						if($v2->r_ans=="OUI")
						{
							$ans[]=1;
						}else if($v2->r_ans=="NON"){
							$ans[]=0;
						}else if($v2->r_ans=="NSP"){
							$ans[]="";
						}else{
							$ans[]="$v2->r_ans";
						}
						//$ans[]=$v2->r_q_num;
						//$ans[]=$v2->r_ans;
					}
					
					$lastcall=date("d.m.y", strtotime($v->cont_lastcall));
					$modified=date("d/m/y", strtotime($v->cont_modified));
					$row = array_merge(array(
						$v->cont_id,
						$v->cont_camp_id,
						$v->cont_callstatus,
						$lastcall,
						$v->cont_counter,
						$v->cont_orirep,
						RevertString($v->cont_specialite),
						RevertString($v->cont_fonction),
						RevertString($v->cont_exercise),
						RevertString($v->cont_civilite),
						RevertString($v->cont_nom),
						RevertString($v->cont_prenom),
						RevertString($v->cont_addr1),
						RevertString($v->cont_addr2),
						RevertString($v->cont_addr3),
						RevertString($v->cont_addr4),
						$v->cont_bp,
						RevertString($v->cont_lieudit),
						$v->cont_cp,
						RevertString($v->cont_ville),
						RevertString($v->cont_pays),
						$v->cont_telephone,
						$v->cont_telecopie,
						$v->cont_email,
						$v->cont_mobile,
						RevertString($v->cont_commentaires),
						$modified
					), $ans);
					for($x=0;$x<=count($excel_fields)-1;$x++)
					{
						$worksheet->write_string($y+$i, $x, $row[$x]);						
					}
					$i++;
			  	}
				$ii=$ii+$d;
			}
			$workbook->close();			
		}
}
*/