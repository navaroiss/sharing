<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Administrator - Login</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>media/css/base.css" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>media/css/style.css" /></head>
<body>
<br/><br/><br/><br/><br/><br/><br/>
<div class="p5" align="center">
<form action="" method="post">
	<table border="1">
		<tr>
			<td>Username: </td>
			<td><input type="text" name="username" /></td>
		</tr>
		<tr>
			<td>Password: </td>
			<td><input type="password" name="password" /></td>
		</tr>
		<tr>	
			<td></td>
			<td><input type="submit" name="sm" value="Login"/></td>
		</tr>
	</table>
</form>
</div>

</body>
</html>