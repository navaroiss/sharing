<?php
/*
 * $Id: Jul 4, 2009 12:00:19 AM navaro  $
 *  
 */

function fetchConfig($data, $key)
{
	foreach($data as $k=>$v)
	{
		if($v->name == $key)
		{
			return $v->value; 
		}
	}
}
 class HTML_Render
 {
 	
 	function HTML_Render()
 	{
 	}
 	
 	function getFieldName($f)
 	{
	 	$names = array(
	 		'width_calendar' => 'Width of Calendar',
	 		'height_calendar' => 'Height of Calendar',
	 		'width_cell' => 'Width of Cell',
	 		'height_cell' => 'Height of Cell',
	 		'border_width' => 'Border width',
	 		'border_color' => 'Border color',
	 		'font_size' => 'Font size',
	 		'font_color' => 'Font color',
	 		'icon_path' => 'Icon path',
	 		'type_allow_upload' => 'File extension allowed',
	 		'date_format' => 'Date format',
	 	);
		return ($names[$f]!='')?$names[$f]:$f;	
 	}
 	
 	function showRecord($data, $config, $calendar_css, $apools)
 	{
 		?>
 			<form action="index.php" method="post" name="adminForm" enctype="multipart/form-data">
 			
				<div class="col width-60">
					<fieldset class="adminform">
						<legend>The way stores user preferences:</legend>
						<table class="admintable">
						<tr>
							<td>
								<select name="config[save_uf_by]">
									<option value="db_table" <?php if(fetchConfig($data, 'save_uf_by')=="db_table") echo "selected='selected'"?>>Database</option>
									<option value="cookies" <?php if(fetchConfig($data, 'save_uf_by')=="cookies") echo "selected='selected'"?>>Cookies</option>
								</select>
							</td>
						</tr>
						</table>
					</fieldset>
				</div>
			  
				<?php 
					if(count($apools)>=1)
					{
				?>
				<div class="col width-60">
					<fieldset class="adminform">
						<legend>Select a poll module:</legend>
						<table class="admintable">
						<tr>
							<td>
								<select name="config[mod_apoll_id]">
								<?php
									foreach($apools as $k=>$v)
									{
										if($v->scope==''){
										$s = (fetchConfig($data, 'mod_apoll_id')==$v->id)?"selected='selected'":'';
										?>
											<option <?php echo $s?> value="<?php echo $v->id?>"><?php echo $v->title?></option>
										<?	
										}
									} 
								?>
								</select>
							</td>
						</tr>
						</table>
					</fieldset>
				</div>
				<?php
					} 
				?>				<div class="col width-60">
					<fieldset class="adminform">
						<legend>Settings:</legend>
		
						<table class="admintable">
					<?php foreach($data as $k=>$v){
						if(!in_array($v->name,array('mod_apoll_id', 'save_uf_by'))){
					?>
						<tr>
							<td class="key">
								<label for="<?php echo $v->name?>">
									<?php echo HTML_Render::getFieldName($v->name) ?>:
								</label>
							</td>
							<td >
								<input class="inputbox" type="text" name="config[<?php echo $v->name?>]" id="<?php echo $v->name?>" size="60" maxlength="255" value="<?php echo $v->value?>" />
							</td>
						</tr>
					<?php }} ?>
						</table>
					</fieldset>
				</div>
				<div class="col width-60">
					<fieldset class="adminform">
						<legend>Custom CSS:</legend>
		
						<table class="admintable">
						<tr>
							<td>
							<textarea name="config[calendar_css]" cols="70" rows="15"><?=$calendar_css->value?></textarea>
							</td>
						</tr>
						</table>
					</fieldset>
				</div>
				<div class="col width-60">
					<fieldset class="adminform">
						<legend>Permission:</legend>
		
						<table class="admintable">
						<!-- 
						<tr>
							<td class="key">
								<label for="">
								Administrator can edit config
								</label>
							</td>
							<td >
								<select name="config[admin_edit_config]">
									<option value="1" <?php if(fetchConfig($config, 'admin_edit_config')==1) echo "selected='selected'"?>>Yes</option>
									 <option value="0" <?php if(fetchConfig($config, 'admin_edit_config')==0) echo "selected='selected'"?>>No</option>
								</select>
							</td>
						</tr>
						 -->
						<tr>
							<td class="key">
								<label for="">
								Editor permission
								</label>
							</td>
							<td >
								Event:<br/>
								<div>
								<select name="config[event][]" multiple="multiple">
									 <option value="editor_create_event" <?php if(fetchConfig($config, 'editor_create_event')==1) echo "selected='selected'"?>>Create</option>
									 <option value="editor_update_event" <?php if(fetchConfig($config, 'editor_update_event')==1) echo "selected='selected'"?>>Update</option>
									 <option value="editor_delete_event" <?php if(fetchConfig($config, 'editor_delete_event')==1) echo "selected='selected'"?>>Delete</option>
								</select>
								</div>
								<br/><br/>
								Article:<br/>
								<div>
								<select name="config[article][]" multiple="multiple">
									 <option value="editor_create_article" <?php if(fetchConfig($config, 'editor_create_article')==1) echo "selected='selected'"?>>Create</option>
									 <option value="editor_update_article" <?php if(fetchConfig($config, 'editor_update_article')==1) echo "selected='selected'"?>>Update</option>
									 <option value="editor_delete_article" <?php if(fetchConfig($config, 'editor_delete_article')==1) echo "selected='selected'"?>>Delete</option>
								</select>
								</div>
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="">
								Registered
								</label>
							</td>
							<td >
								Event for Registered user:	
								<div>
									<input <?php if(fetchConfig($config, 'registered_view_event_registered')==2) echo "checked='checked'"?> type="radio" name="config[registered_view_event_registered]" id="registered_view_event_registered_1" value="2"/>
									<label for="registered_view_event_registered_1">Yes</label>
									<input <?php if(fetchConfig($config, 'registered_view_event_registered')!=2) echo "checked='checked'"?> type="radio" name="config[registered_view_event_registered]" id="registered_view_event_registered_0" value="0"/>
									<label for="registered_view_event_registered_0">No</label>
								</div>
								
								Public event: 
								<div>
									<input <?php if(fetchConfig($config, 'registered_view_event_public')==1) echo "checked='checked'"?> type="radio" name="config[registered_view_event_public]" id="registered_view_event_public_1" value="1"/>
									<label for="registered_view_event_public_1">Yes</label>
									<input <?php if(fetchConfig($config, 'registered_view_event_public')!=1) echo "checked='checked'"?> type="radio" name="config[registered_view_event_public]" id="registered_view_event_public_0" value="0"/>
									<label for="registered_view_event_public_0">No</label>
								</div>
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="">
								Guest can view public events.
								</label>
							</td>
							<td >
								<select name="config[guest_view]">
									<option value="1" <?php if(fetchConfig($config, 'guest_view')==1) echo "selected='selected'"?>>Yes</option>
									<option value="0" <?php if(fetchConfig($config, 'guest_view')==0) echo "selected='selected'"?>>No</option>
								</select>
							</td>
						</tr>
						</table>
					</fieldset>
				</div>
				<div class="clr"></div>
				<?php JHTML::_('behavior.calendar'); ?>
				<input type="hidden" name="c" value="<?php echo JRequest::getVar('c')?>" />
				<input type="hidden" name="option" value="<?php echo JRequest::getVar('option')?>" />
				<input type="hidden" name="id" value="<?php echo $row->id; ?>" />
				<input type="hidden" name="task" value="<?php echo JRequest::getVar('task')?>" />
				<input type="hidden" name="action" value="<?php echo $edit==true?'edit':'add'?>" />
				<?php echo JHTML::_( 'form.token' ); ?>
			</form>			
 		<?
 	}
 }
?>