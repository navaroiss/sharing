<?php
	class Render_HTML
	{
		function indexing($data, $parent=0)
		{
			foreach($data as $k=>$v)
			{
				if($v->id==$parent)
					return $v->name;
			}
			return 'ROOT';
		}
		function editRecord($edit, $row, $icon_path)
		{
			$editor =& JFactory::getEditor();
			?>
			<form action="index.php" method="post" name="adminForm" enctype="multipart/form-data">
				<div class="col width-60">
					<fieldset class="adminform">
						<legend><?php echo JText::_( 'Details' ); ?></legend>
		
						<table class="admintable">
						<tr>
							<td class="key">
								<label for="name">
									<?php echo JText::_( 'Category name' ); ?>:
								</label>
							</td>
							<td >
								<input class="inputbox" type="text" name="category[name]" id="name" size="60" maxlength="255" value="<?php echo $row->name; ?>" />
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="name">
									<?php echo JText::_( 'Category parent' ); ?>:
								</label>
							</td>
							<td >
						 			<?php echo getCategories($row->parent);?>
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="name">
									<?php echo JText::_( 'Description' ); ?>:
								</label>
							</td>
							<td >
						<?php echo $editor->display( 'category[description]',  $row->description, 
													'550', '300', '60', '15', array('readmore') ) ;	?>
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="name">
									<?php echo JText::_( 'Icon' ); ?>:
								</label>
							</td>
							<td >
								<?php 
								echo JHTML::_('list.images',  'image', $row->icon, "onchange=\"window.document.imagelib.src='..{$icon_path}'+this.value\"", 
											$icon_path );?>
								<br/><img name="imagelib" src="<?php echo JURI::root().$icon_path.$row->icon?>" />

<!-- 
 **** Su dung chuc nang media cua Joomla
 					
								<input class="inputbox" type="file" name="icon" id="name" size="60" maxlength="255" />
								<?php if($edit==true && $row->icon!=''){?>
								<br/><img name="imagelib" src="<?php echo JURI::root() ?>/tmp/<?php echo $row->icon?>" />								
								<br />
								Delete document: <input type="checkbox" name="delete_icon" value="1" />
								<?php } ?>
 -->
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="select_by_default"><?php echo JText::_("Always");?> :</label>
							</td>
							<td>
								<select id="select_by_default" name="category[selected_by_default]">
									<option value="1" <?php if($row->selected_by_default==1) echo "selected='selected'"?>>Selected</option>
									<option value="0" <?php if($row->selected_by_default==0) echo "selected='selected'"?>>UnSelected</option>
								</select>
							</td>
						</tr>
						</table>
					</fieldset>
				</div>
					
				<div class="col width-40"></div>
				<div class="clr"></div>
		
				<input type="hidden" name="c" value="<?php echo JRequest::getVar('c')?>" />
				<input type="hidden" name="option" value="<?php echo JRequest::getVar('option')?>" />
				<input type="hidden" name="id" value="<?php echo $row->id; ?>" />
				<input type="hidden" name="task" value="<?php echo JRequest::getVar('task')?>" />
				<input type="hidden" name="action" value="<?php echo $edit==true?'edit':'add'?>" />
				<?php echo JHTML::_( 'form.token' ); ?>
			</form>			
			<?
		}
		
		function showRecord($rows, $page, $icon_path)
		{
			?>
				<form action="index.php" method="post" name="adminForm">

					<table class="adminlist">
					<thead>
						<tr>
							<th width="10">
								<?php echo JText::_( 'NUM' ); ?>
							</th>
							<th width="10">
								<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $rows );?>);" />
							</th>
							<th class="title">
								Icon
							</th>
							<th class="title">
								Category name
							</th>
							<th class="title">
								Description
							</th>
							<th class="title">
								Parent
							</th>
							<th class="title" width="40">
								Selected
							</th>
							<th class="title" width="40">
								Action
							</th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<td colspan="7">
								<?php echo $page->getListFooter(); ?>
							</td>
						</tr>
					</tfoot>
					<tbody>
						<?php
							$i=0; 
							foreach($rows as $k=>$v){
								$checked 	= JHTML::_('grid.checkedout',   $v, $i );
								?>
								<tr>
									<td><?php echo $page->getRowOffset( $i ); ?></td>
									<td><?php echo $checked?></td>
									<td>
									<?php
										if($v->icon!='')
											echo "<img src='".JURI::root().$icon_path.$v->icon."'/>";
									?></td>
									<td><?php echo $v->name?></td>
									<td width="500"><?php echo substr(strip_tags($v->description), 0, 255)?></td>
									<td><?php echo Render_HTML::indexing($rows, $v->parent);?></td>
									<td>
									<?php 
										echo ($v->selected_by_default==1)?"<img src='images/tick.png'/>":"";
									?>
									</td>
									<td>
										<a href="index.php?option=com_agenda&c=categories&task=edit&id=<?php echo $v->id?>"><img src="<?=JURI::root().'administrator/components/com_agenda/assets/edit.png'?>"/></a>
									</td>
								</tr>
								<?php 
								$i++;
							}
						?>
					</tbody>
					</table>
				<input type="hidden" name="c" value="<?php echo JRequest::getVar('c')?>" />
				<input type="hidden" name="option" value="<?php echo JRequest::getVar('option')?>" />
				<input type="hidden" name="id" value="<?php echo $row->id; ?>" />
				<input type="hidden" name="task" value="<?php echo JRequest::getVar('task')?>" />
				<input type="hidden" name="boxchecked" value="0" />
	
				<?php echo JHTML::_( 'form.token' ); ?>
				</form>
			<?
		}
		
	}
?>