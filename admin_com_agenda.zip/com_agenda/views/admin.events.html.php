<?php
	class Render_HTML
	{
		function editRecord($edit, $row, $icon_path)
		{
			$editor =& JFactory::getEditor();
			?>
			<form action="index.php" method="post" name="adminForm" enctype="multipart/form-data">
				<div class="col width-60">
					<fieldset class="adminform">
						<legend><?php echo JText::_( 'Details' ); ?></legend>
		
						<table class="admintable">
						<tr>
							<td class="key">
								<label for="name">
									<?php echo JText::_( 'Title' ); ?>:
								</label>
							</td>
							<td >
								<input class="inputbox" type="text" name="event[title]" id="name" size="60" maxlength="255" value="<?php echo $row->title; ?>" />
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="name">
									<?php echo JText::_( 'Category' ); ?>:
								</label>
							</td>
							<td >
						 			<?php echo getCategories($row->cat_id, "event[cat_id]");?>
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="name">
									<?php echo JText::_( 'Description' ); ?>:
								</label>
							</td>
							<td >
						<?php echo $editor->display( 'event[description]',  $row->description, 
													'550', '150', '60', '10', array('readmore') ) ;	?>
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="name">
									<?php echo JText::_( 'Content' ); ?>:
								</label>
							</td>
							<td >
						<?php echo $editor->display( 'event[content]',  $row->content, 
													'550', '300', '60', '15', array('readmore') ) ;	?>
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="name">
									<?php echo JText::_( 'Attachment' ); ?>:
								</label>
							</td>
							<td >
								<input class="inputbox" type="file" name="document" id="name" size="60" maxlength="255" />
								<?php if($edit==true && $row->attach!=''){?>								
								<br />
								Delete document: <input type="checkbox" name="delete_attach" value="1" /><br/>
								<a href="../tmp/<?php echo $row->attach?>">Download</a>
								<?php } ?>
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="name">
									<?php echo JText::_( 'FMC' ); ?>:
								</label>
							</td>
							<td>
								<select name="event[fmc]">
									<option value="1" <?php if($row->fmc==1) echo "selected='selected'"?>>True</option>
									<option value="0" <?php if($row->fmc==0) echo "selected='selected'"?>>False</option>
								</select>
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="name">
									<?php echo JText::_( 'Icon' ); ?>:
								</label>
							</td>
							<td>
								<?php 
								echo JHTML::_('list.images',  'image', $row->icon, "onchange=\"window.document.imagelib.src='..{$icon_path}'+this.value\"", 
											$icon_path );?>
								<br/><img name="imagelib" src="<?php echo JURI::root().$icon_path.$row->icon?>" />
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="name">
									Start date:
								</label>
							</td>
							<td >
								<input class="inputbox" value="<?php echo $row->start_date?>" type="text" name="event[start_date]" id="start_date" size="60" maxlength="255" />
								<img class="calendar" src="templates/system/images/calendar.png" alt="calendar" onclick="return showCalendar('start_date', '%Y-%m-%d');" /> 
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="name">
									End date:
								</label>
							</td>
							<td >
								<input class="inputbox" value="<?php echo $row->end_date?>" type="text" name="event[end_date]" id="end_date" size="60" maxlength="255" />
								<img class="calendar" src="templates/system/images/calendar.png" alt="calendar" onclick="return showCalendar('end_date', '%Y-%m-%d');" /> 
							</td>
						</tr>
						<tr>
							<td class="key">
								<label for="name">
									Viewer:
								</label>
							</td>
							<td >
								<select name="event[public]">
									<option value="1" <?php if($row->public==1) echo "selected='selected'"?>>Public</option>
									<option value="2" <?php if($row->public==2) echo "selected='selected'"?>>Registered</option>
								</select>
							</td>
						</tr>
						</table>
					</fieldset>
				</div>
					
				<div class="col width-40"></div>
				<div class="clr"></div>
				<?php JHTML::_('behavior.calendar'); ?>
				<input type="hidden" name="c" value="<?php echo JRequest::getVar('c')?>" />
				<input type="hidden" name="option" value="<?php echo JRequest::getVar('option')?>" />
				<input type="hidden" name="id" value="<?php echo $row->id; ?>" />
				<input type="hidden" name="task" value="<?php echo JRequest::getVar('task')?>" />
				<input type="hidden" name="action" value="<?php echo $edit==true?'edit':'add'?>" />
				<?php echo JHTML::_( 'form.token' ); ?>
			</form>			
			<?
		}
		
		function showRecord($rows, $page,$icon_path, $lists)
		{
			?>
				<form action="index.php" method="post" name="adminForm">

		<table>
			<tr>
				<td align="left" width="100%">
					<!--<input type="text" name="search" id="search" value="<?php echo $lists['search'];?>" class="text_area" onchange="document.adminForm.submit();" />
					<button onclick="this.form.submit();"><?php echo JText::_( 'Go' ); ?></button>
					<button onclick="document.getElementById('search').value='';this.form.getElementById('sectionid').value='-1';this.form.getElementById('filter_state').value='';this.form.submit();"><?php echo JText::_( 'Reset' ); ?></button>-->
				</td>
				<td nowrap="nowrap">
					<?php echo JText::_( 'Filter' ); ?>:
					<script type="text/javascript">
					function changeURL()
					{
						month = document.adminForm.month.value;
						year = document.adminForm.year.value;
						document.adminForm.my_token.value=1;
						if(month>=1 && year ==0)
						{
							document.adminForm.year.value = <?=date('Y')?>
						}else if (year>=<?=date('Y')?> && month==0)
						{
							document.adminForm.month.value = <?=date('m')?>
						}
						document.adminForm.submit(); 
					}
					</script>
					<input type="hidden" name="my_token" value="0" />
					 <select name="month" onchange="javascript:changeURL()">
					 <option value='0' <? if ($_POST['month'] == 0) echo "selected='selected'"?>>Select month</option>
						<?
							$month_array = array("JANUARY", "FEBRUARY", "MARCH", "APRIL",
								"MAY", "JUNE", "JULY", "AUGUST", 
								"SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER");
							$i=1;
							foreach($month_array as $k=>$v)
							{
								$s = ($i==$lists['current_month'])?"selected='selected'":'';
							 ?>
							 <option <? echo $s ?> value="<? echo $i ?>"><? echo JText::_($v) ?></option>
							 <?
							 $i++;
							}
						 ?>
					</select>
					&nbsp;&nbsp;&nbsp;
					<select name="year" onchange="javascript:changeURL()">
					<option value='0' <? if ($_POST['year'] == 0) echo "selected='selected'"?>>Select year</option>
						<?
							$year_start = 2008;
							for($i=$year_start;$i<=$year_start+10;$i++)
							{
							 $s = ($i==$lists['current_year'])?"selected='selected'":'';
							 ?>
							 <option <? echo $s ?> value="<? echo $i ?>"><? echo $i; ?></option>
							 <?
							}
						 ?>
					</select>
					<?php
					if ( count($lists['catid'])>=1 ) {
						echo $lists['catid'];
					}
					echo "Category: ". getCategories($_POST['catid'], "catid", 'onchange="document.adminForm.submit();"', '');
					?>
				</td>
			</tr>
		</table>

					<table class="adminlist">
					<thead>
						<tr>
							<th width="10">
								<?php echo JText::_( 'NUM' ); ?>
							</th>
							<th width="10">
								<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $rows );?>);" />
							</th>							
							<th class="title">
								Icon
							</th>
							<th class="title">
								Category
							</th>
							<th class="title">
								Title
							</th>
							<th class="title">
								Description
							</th>
							<th class="title">
								Start date / End date
							</th>
							<th class="title">
								FMC
							</th>
							<th class="title">
								Access level
							</th>
							<th class="title" width="40">
								Action
							</th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<td colspan="10">
								<?php echo $page->getListFooter(); ?>
							</td>
						</tr>
					</tfoot>
					<tbody>
						<?php
							$i=0; 
						if(count($rows)>=1){
							foreach($rows as $k=>$v){
								$checked 	= JHTML::_('grid.checkedout',   $v, $i );
								?>
								<tr>
									<td><?php echo $page->getRowOffset( $i ); ?></td>
									<td><?php echo $checked?></td>
									<td><?php
										if($v->icon!='')
											echo "<img src='".JURI::root().$icon_path.$v->icon."'/>";
										else
											echo "<img src='".JURI::root().$icon_path.$v->c_icon."'/>";
									?></td>
									<td><?php
											echo $v->name;
									?></td>
									<td><?php echo $v->title?></td>
									<td width="500"><?php echo substr(strip_tags($v->description), 0, 255)?></td>
									<td><?php echo $v->start_date." - ".$v->end_date?></td>
									<td>
										<?php 
											echo ($v->fmc==1)?"<img src='images/tick.png'/>":"<img src='images/publish_x.png'/>";
										?>
									</td>
									<td>
										<?php 
											if($v->public==1) echo "Public";
											if($v->public==2) echo "Registered";
										?>
									</td>
									<td>
										<a href="index.php?option=com_agenda&c=events&task=edit&id=<?php echo $v->id?>"><img src="<?=JURI::root().'administrator/components/com_agenda/assets/edit.png'?>"/></a>
									</td>
								</tr>
								<?php 
								$i++;
							}
						}
						?>
					</tbody>
					</table>
				<input type="hidden" name="c" value="<?php echo JRequest::getVar('c')?>" />
				<input type="hidden" name="option" value="<?php echo JRequest::getVar('option')?>" />
				<input type="hidden" name="id" value="<?php echo $row->id; ?>" />
				<input type="hidden" name="task" value="<?php echo JRequest::getVar('task')?>" />
				<input type="hidden" name="boxchecked" value="0" />
	
				<?php echo JHTML::_( 'form.token' ); ?>
				</form>
			<?
		}
		
	}
?>