<?php

	jimport('joomla.application.component.controller');
	include_once( dirname(__FILE__).DS.'Interface.php' );
	
	class EventsController extends JController //implements Controller_Interface 
	{
		
		var $c = 'events';
		var $option = 'com_agenda';
		var $tbl = 'agenda_events';
		
		function EventsController()
		{
			$GLOBALS['db'] = new OnlyModels();	
		}
		
		function editRecord($edit)
		{
			global $db;
			// Toolbar
			$title = ($edit==false)?"Create new event":"Edit event";
			JToolBarHelper::title( JText::_( $title ), 'generic.png' );
			JToolBarHelper::save( 'save' );
			JToolBarHelper::apply('apply');
			JToolBarHelper::cancel( 'cancel' );
			
			$id =& JRequest::getVar('id', '', 'get', 'int');
			
			$data = $db->loadRecord($this->getDataTbl(), '*', array('id'=>$id)); //print_r($data);
			
			$config = $db->loadRecord('agenda_config', 'value', array('name'=>'icon_path')); 
			return Render_HTML::editRecord($edit, $data, $config->value);	
		}

		function saveRecord($_POST, $action = '')
		{
			global $db, $mainframe;
			$event = $_POST['event']; 
			$id = $_POST['id'];
			
			$data = new stdClass();
			$data->title = $event['title'];
			$data->description = stripcslashes($event['description']);
			$data->content = stripcslashes($event['content']);
			$data->fmc = $event['fmc'];
			$data->public = $event['public'];
			//die(strftime("%Y-%m-%d", strtotime($event['start_date'])));

			//$config =& JFactory::getConfig();
			//$tzoffset = $config->getValue('config.offset');

			//$date =& JFactory::getDate($_POST['event']['start_date'], $tzoffset);
			$data->start_date = $_POST['event']['start_date'];//$date->toMySQL();

			//$date =& JFactory::getDate($_POST['event']['end_date'], $tzoffset);
			$data->end_date = $_POST['event']['end_date'];//$date->toMySQL();

			$data->cat_id = $event['cat_id'];
			$data->icon = $_POST['image'];;
			
			$config_file_allow = $db->loadRecord('agenda_config', 'value', array('name'=>'type_allow_upload'));
			$file_allow_upload = explode(',', $config_file_allow->value);
			//print_r($file_allow_upload);die();exit(); 
			
			$file = JRequest::getVar('document', null, 'files', 'array');
			jimport('joomla.filesystem.file');
			$filename = JFile::makeSafe($file['name']);
			$src = $file['tmp_name'];
			$dest = dirname(JPATH_BASE) . DS . "tmp" . DS . $filename; //die($dest);
			if ( in_array(strtolower(JFile::getExt($filename) ), $file_allow_upload) && JFile::upload($src, $dest)) {
				if (JFile::exists($dest))
					 $data->attach = $filename;// echo $dest;die();
			}
			
			if($_POST['delete_attach']==1){
				$data->attach='';
			}

			if($action=="edit"){
				$data->id = $id;
				$db->updateRecord($this->getDataTbl(), $data, 'id');
				$db->query();
			}else{
				$db->insertRecord($this->getDataTbl(), $data);
			}
			
			$this->refresh();
		}
		
		function showRecord()
		{
			global $db, $mainframe;
			jimport('joomla.html.pagination');
			
			JToolBarHelper::title( 'Show Agenda events', 'generic.png' );
			JToolBarHelper::archiveList();
			JToolBarHelper::unarchiveList();
			JToolBarHelper::addNewX();
			JToolBarHelper::deleteList( "Are you sure? " , 'remove');
			
			$limit		= $mainframe->getUserStateFromRequest( 'global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int' );
			$limitstart	= $mainframe->getUserStateFromRequest( $option.'.limitstart', 'limitstart', 0, 'int' );
						
			//$total = $db->loadRecords($this->getDataTbl(), '', 0, 0, true);
			//$paging = new JPagination($total, $limitstart, $limit);

			$extr = array(
				'select'=>'#__agenda_categories.icon as c_icon, #__agenda_categories.name',
				'table'=>'#__agenda_categories',
				'condition'=>'#__agenda_categories.id = #__agenda_events.cat_id'
			);
			$where = '';
			
			$month = (isset($_POST['month']))?$_POST['month']:0;
			$year = (isset($_POST['year']))?$_POST['year']:0;

			if(intval($_POST['catid'])>=1)
				$where = " where #__agenda_events.cat_id=".intval($_POST['catid']);
			if(intval($_POST['catid'])>=1)
				$where .= " and (#__agenda_events.end_date >= '$year-$month-01' and #__agenda_events.start_date <= '$year-$month-31')";
			elseif($_POST['month']>=1)
				$where .= " where (#__agenda_events.end_date >= '$year-$month-01' and #__agenda_events.start_date <= '$year-$month-31')";

			$total = $db->loadRecords($this->getDataTbl(), $where, $limitstart, $limit, true, $extr);
			$data = $db->loadRecords($this->getDataTbl(), $where, $limitstart, $limit, false, $extr);
			$paging = new JPagination($total, $limitstart, $limit);
			//echo $db->getQuery();
			//$db->setQuery("select name, id from #__agenda_categories");
			//$categories[] = JHTML::_('select.option', '0', '- '.JText::_('Select a category').' -', 'id', 'name');
			//$categories = array_merge($categories, $db->loadObjectList());			
			//$javascript = 'onchange="document.adminForm.submit();"';
			//$lists['catid'] = JHTML::_('select.genericlist',  $categories, 'catid', $javascript, 'id', 'name', $_POST['catid']);
			$lists['current_month'] = $month;
			$lists['current_year'] = $year;
			$config = $db->loadRecord('agenda_config', 'value', array('name'=>'icon_path')); 
			return Render_HTML::showRecord($data, $paging,$config->value,$lists);
		}
		
		function removeRecord()
		{
			global $db;
			$db->removeRecords($this->getDataTbl(), array_values($_POST['cid']));
			$this->refresh();
		}
		
		function refresh($params = array())
		{	
			global $mainframe;
			$url = "index.php?option=".$this->option."&c=".$this->c;
			if(is_array($params) && count($params)>=1){
				foreach($params as $k=>$v){
					$p[] = "$k=$v"; 
				}
				$url .= implode('&', $p);
			}
			$mainframe->redirect($url);
		}
		
		function getDataTbl()
		{
			return $this->tbl;
		}
	}
?>