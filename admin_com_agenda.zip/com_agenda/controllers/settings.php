<?php
/*
 * $Id: Jul 4, 2009 12:00:37 AM navaro  $
 *  
 */
 
 jimport('joomla.application.component.controller');
 
 class SettingsController extends JController
 {
 	var $c = "settings";
	var $option = 'com_agenda';
	var $tbl = 'agenda_config';
 	
 	function SettingsController()
 	{
		$db = new OnlyModels();
		$GLOBALS['db'] = $db;
		$GLOBALS['user'] =& JUser::getInstance();
		$GLOBALS['acl'] =& JFactory::getACL();
	}

	function getDataTbl()
	{
		return $this->tbl;
	}
 	
 	function showRecord()
 	{
 		global $db, $acl, $user;
 		$data = $db->loadRecords($this->getDataTbl(), array('scope'=>''), 0, 100);
		JToolBarHelper::title( 'Settings', 'generic.png' );
		JToolBarHelper::save( 'save' );
		JToolBarHelper::cancel( 'cancel' );

		$config = $db->loadRecords($this->getDataTbl(),array('scope'=>'permission'),0,100);
		
		/*
		$gtree = $acl->get_group_children_tree( null, 'USERS', false );
		$list_group 	= JHTML::_('select.genericlist',   $gtree, 'gid', 'size=""', 'value', 'text', $user->get('gid') );
		echo $list_group;
		*/
		$modsapoll = array();
		$calendar_css = $db->loadRecord($this->getDataTbl(), $fields = '*', $record_id = array('name'=>'calendar_css'));
		$modsapoll =$db->loadRecords("modules", array('module'=>'mod_apoll', 'published'=>1), 0, 100);
		
		return HTML_Render::showRecord($data, $config, $calendar_css, $modsapoll);
 	}

  	function saveRecord()
 	{
 		global $db;
 		$event = array('editor_create_event', 'editor_update_event', 'editor_delete_event');
 		$article = array('editor_create_article', 'editor_update_article', 'editor_delete_article');
 		$list = array(
 			'event' => array('editor_create_event', 'editor_update_event', 'editor_delete_event'),
 			'article' => array('editor_create_article', 'editor_update_article', 'editor_delete_article')
 		);
 		//print_r($_POST);die();
 		foreach($_POST['config'] as $k=>$v)
 		{
 			$data =& new stdClass;
 			if(is_array($v)){
 				for($i=0;$i<=count($list[$k])-1;$i++)
 				{
					$data->name = $list[$k][$i];
					$data->value = in_array($list[$k][$i], $v) ?1:0;//print_r($data);
		 			$db->updateRecord($this->getDataTbl(), $data, 'name');
		 			$db->query();
 				}
 			}else{
	 			$data->name = $k;
	 			$data->value = $v;
	 			$db->updateRecord($this->getDataTbl(), $data, 'name');
	 			//print_r($data);
	 			//$db->query();
 			}
 		}
 		
 		$this->refresh();	
 	}

 	function refresh($params = array())
	{	
		global $mainframe;
		$url = "index.php?option=".$this->option."&c=".$this->c;
		if(is_array($params) && count($params)>=1){
			foreach($params as $k=>$v){
				$p[] = "$k=$v"; 
			}
			$url .= implode('&', $p);
		}
		$mainframe->redirect($url);
	}
 	
 }
?>