<?php
	/*
	interface Controller_Interface
	{
		public function editRecord($edit);
		public function saveRecord($data, $action = '');
		public function showRecord();
		public function removeRecord();
	}
	*/
?>