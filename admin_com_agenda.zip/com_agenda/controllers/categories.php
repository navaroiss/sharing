<?php

	jimport('joomla.application.component.controller');
	include_once( dirname(__FILE__).DS.'Interface.php' );
	
	class CategoriesController extends JController //implements Controller_Interface 
	{
		
		var $c = 'categories';
		var $option = 'com_agenda';
		var $tbl = 'agenda_categories';
		
		function CategoriesController()
		{
			$db = new OnlyModels();
			$GLOBALS['db'] = $db;	
		}
		
		function editRecord($edit)
		{
			global $db;
			// Toolbar
			$title = ($edit==false)?"Create new category":"Edit Category";
			JToolBarHelper::title( JText::_( $title ), 'generic.png' );
			JToolBarHelper::save( 'save' );
			JToolBarHelper::apply('apply');
			JToolBarHelper::cancel( 'cancel' );
			
			$id =& JRequest::getVar('id', '', 'get', 'int');
			
			$data = $db->loadRecord($this->getDataTbl(), '*', array('id'=>$id)); //print_r($data);
			
			$config = $db->loadRecord('agenda_config', 'value', array('name'=>'icon_path')); 
			return Render_HTML::editRecord($edit, $data, $config->value);	
		}

		function saveRecord($_POST, $action = '')
		{
			global $db, $mainframe;
			$category = $_POST['category'];
			$id = $_POST['id'];
			
			$data = new stdClass();
			
			$data->name = $category['name'];
			$data->parent = $category['parent'];
			$data->description = stripcslashes($category['description']);
			$data->icon = $_POST['image'];
			$data->selected_by_default = $category['selected_by_default'];
			
			$file = JRequest::getVar('icon', null, 'files', 'array');
			jimport('joomla.filesystem.file');
			$filename = JFile::makeSafe($file['name']);
			$src = $file['tmp_name'];
			$dest = dirname(JPATH_BASE) . DS . "tmp" . DS . $filename; //die($dest);
			$img_ext = array('jpg','jpeg','png','gif');
			if ( in_array(strtolower(JFile::getExt($filename) ), $img_ext) && JFile::upload($src, $dest)) {
				if (JFile::exists($dest))
					 $data->icon = $filename;// echo $dest;die();
			}
			
			if($action=="edit"){
				$data->id = $id;
/*				if($_POST['delete_icon']==1) $data->icon = '';*/
				$db->updateRecord($this->getDataTbl(), $data, 'id');
				$db->query();
			}else{
				$db->insertRecord($this->getDataTbl(), $data);
			}
			
			$this->refresh();
		}
		
		function showRecord()
		{
			global $db, $mainframe;
			jimport('joomla.html.pagination');
			
			JToolBarHelper::title( 'Show Agenda Categories', 'generic.png' );
			JToolBarHelper::addNewX();
			JToolBarHelper::deleteList( "Are you sure? " , 'remove');
			
			$limit		= $mainframe->getUserStateFromRequest( 'global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int' );
			$limitstart	= $mainframe->getUserStateFromRequest( $option.'.limitstart', 'limitstart', 0, 'int' );
						
			$total = $db->loadRecords($this->getDataTbl(), '', 0, 0, true); //print_r($total);
			$paging = new JPagination($total, $limitstart, $limit);
			$data = $db->loadRecords($this->getDataTbl(), '', $limitstart, $limit); 
			
			$config = $db->loadRecord('agenda_config', 'value', array('name'=>'icon_path')); 
			return Render_HTML::showRecord($data, $paging, $config->value);
		}
		
		function removeRecord()
		{
			global $db;
			$db->removeRecords($this->getDataTbl(), array_values($_POST['cid']));
			$this->refresh();
		}
		
		function refresh($params = array())
		{	
			global $mainframe;
			$url = "index.php?option=".$this->option."&c=".$this->c;
			if(is_array($params) && count($params)>=1){
				foreach($params as $k=>$v){
					$p[] = "$k=>$v"; 
				}
				$url .= implode('&', $p);
			}
			$mainframe->redirect($url);
		}
		
		function getDataTbl()
		{
			return $this->tbl;
		}
	}
?>