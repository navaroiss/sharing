<?php

	$c =& JRequest::getCmd('c','events');
	$task =& JRequest::getCmd('task','show');
	$action =& JRequest::getCmd('action','');
	
	/*
	$user = & JFactory::getUser(); //die($task);
	if (!$user->authorize( 'com_agenda', $task )) {
		$mainframe->redirect( 'index.php', JText::_('ALERTNOTAUTH') );
	}*/

	include_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'controllers'.DS."$c.php" );
	include_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'models'.DS."models.php" );
	include_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS."helper.php" );
	include_once( JPATH_COMPONENT_ADMINISTRATOR.DS.'views'.DS."admin.$c.html.php" );
	
	$cotroller_name = ucfirst($c)."Controller";
	$controller = new $cotroller_name();
	
	switch(strtolower($task))
	{
		case 'add':
			$controller->editRecord(false); break;
		case 'edit':
			$controller->editRecord(true); break;
		case 'remove':
		case 'removeRecord':
			$controller->removeRecord(); break;
		case 'apply':
		case 'save':
		case 'save2new':
		case 'save2copy':
			$controller->saveRecord( $_POST, $action ); break;
		default:
			$controller->showRecord(); break;
	}
		
?>