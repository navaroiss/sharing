<?php
/*
 * $Id: Jul 3, 2009 11:26:03 AM navaro  $
 *  
 */
 function getCategories($parent=0, $field_name = 'category[parent]', $js = '', $root_value=0)
 {
  $conf =& JFactory::getConfig();
  $html = "<select $js name='".$field_name."'>";
  $s = ($parent==0)?'selected="selected"':'';
  $html .= "<option value='$root_value' $s>ROOT</option>"; 
  $selcat="SELECT * from ".$conf->getValue('config.dbprefix')."agenda_categories order by name ASC";
  $selcat2= mysql_query($selcat) or die("Could not select category");
  $html .= traverse(0,0,$selcat2, $parent);
  $html .= "</select><br>";
  return $html;
 }

 function traverse($root, $depth, $sql, $parent=0) 
 { 
     $row=0;
     while ($acat = mysql_fetch_array($sql)) 
     { 
          if ($acat['parent'] == $root) 
          { 
			   $s = ($parent==$acat['id'])?'selected="selected"':'';
               $t .= "<option value='" . $acat['id'] . "' $s>"; 
               $j=0; 
               while ($j<$depth) 
               {     
                     $t .= "&nbsp;&nbsp;";
                    $j++; 
               } 
               if($depth>0)
               {
                 $t .= "-";
               }
               $t .= $acat['name'] . "</option>"; 
               @mysql_data_seek($sql,0); 
               $t .= traverse($acat['id'], $depth+1,$sql, $parent); 
          } 
          $row++; 
          @mysql_data_seek($sql,$row); 
     } 
     return $t;
 }	
 ?>