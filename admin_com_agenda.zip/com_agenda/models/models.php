<?php

	class OnlyModels extends JDatabaseMySQL 
	{

		var $db = null;
		  
		var $sql = '';
		
		function OnlyModels()
		{
			$conf =& JFactory::getConfig();
			$host 		= $conf->getValue('config.host');
			$user 		= $conf->getValue('config.user');
			$password 	= $conf->getValue('config.password');
			$database	= $conf->getValue('config.db');
			$prefix 	= $conf->getValue('config.dbprefix');
			$driver 	= $conf->getValue('config.dbtype');
			$debug 		= $conf->getValue('config.debug');
			$options	= array ( 'driver' => $driver, 'host' => $host, 
									'user' => $user, 'password' => $password, 
									'database' => $database, 'prefix' => $prefix );
			parent::__construct($options);
		}
		
		function loadRecord($table, $fields = '*', $record_id = array())
		{
			$fields_str = '*';
			$where = '';
			$key = 'id';
			$sql = "select %s from %s where %s";
			
			if(is_array($fields) && count($fields)>=1){
				$fields_str = implode(',', $fields);
			}
			
			if(is_array($record_id) && count($record_id)>=1){
				foreach($record_id as $k=>$v)
				{
					$where[] = "$k='$v'";
				}
				$where = implode(" and ", $where);
			}else{
				$where = "$key = $record_id";
			}
			
			$sql = sprintf($sql, $fields_str, $this->getPrefix().$table, $where);
			$this->setQuery($sql);
			return $this->loadObject();
		}
		
		function loadRecords($table='', $where='', $limitstart, $limit, $total = false, $inner_join=array())
		{


			$inj = '';
			$ins = '';
			if(count($inner_join)>=1){
				$ins = ", ".$inner_join['select'];
				$inj = " left join ".$inner_join['table'].' on '.$inner_join['condition'];
			}

			$sql = "select %s %s from %s %s %s";

			if(is_array($where)){
				foreach($where as $k=>$v)
				{
					$w[] = "`$k`='$v'";
				}
			}
			
			$where = (is_array($w))?" where ".implode(' and ', $w):$where;
			
			if($total == true){
				$sql = sprintf($sql, "count(*)", '', $this->getPrefix().$table, $inj, $where); 
				$this->setQuery($sql); //echo($this->getQuery());
				return $this->loadResult();
			}
			$sql = sprintf($sql, $this->getPrefix().$table.".*", $ins, $this->getPrefix().$table, $inj, $where); 
			$this->setQuery($sql, $limitstart, $limit);// echo($this->getQuery());
			return $this->loadObjectList();
		}
		
		function updateRecord($table, $data, $k)
		{ 
			return $this->updateObject($this->getPrefix().$table, $data, $k);
		}
		
		function insertRecord($table, $data)
		{
			return $this->insertObject($this->getPrefix().$table, $data);
		}
		
		function removeRecords($table = '', $record = array(), $key = 'id')
		{
			$sql = "delete from %s %s";
			$where = '';
			if(is_array($record) && count($record)>=1)
			{
				$where = " where `$key` in (".implode(',', $record).")";
			}
			$sql = sprintf($sql, $this->getPrefix().$table, $where); 
			$this->setQuery($sql); $this->query();
		}
		
	}

?>