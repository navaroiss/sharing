import os
os.environ['DJANGO_SETTINGS_MODULE'] = 'settings'
import settings

from django.db.models import Q
from papershare.models import PaperShareProfile, Request,\
REQ_STA_ASSIGNED, REQ_STA_FAILED, REQ_STA_LASTCHANCE, REQ_STA_PENDING, REQ_STA_REASSIGNED, REQ_STA_SUPPLIED, REQ_STA_THANKED

i = 0

def setup():
    global i
    suppliers = PaperShareProfile.objects.filter(is_supplier=1)
    for item in suppliers:
        print "Username: " + item.user.username
        print "Ngay dang tham gia: " + str(item.user.date_joined) 
        print "Ngay dang nhap gan day: " + str(item.user.last_login)
        print "So bai bao duoc phan cong: " + str(Request.objects.filter(supplier=item.user.id).count())
        
        SUPPLIED_STATUS = [REQ_STA_SUPPLIED, REQ_STA_THANKED]
        print "So bai bao da cung cap: " + str(Request.objects.filter(Q(status__in=SUPPLIED_STATUS), Q(supplier=item.user.id)).count())
        
        BAD_STATUS = [REQ_STA_PENDING, REQ_STA_ASSIGNED, REQ_STA_REASSIGNED, REQ_STA_LASTCHANCE]
        print "So bai bao hien dang tre: " + str(Request.objects.filter(Q(supplier=item.user.id),Q(status__in=BAD_STATUS)).count())        

        i = i + 1
        print "========================="
    print "Tong so supplier: " + str(i) 

if __name__ == "__main__":
    setup()