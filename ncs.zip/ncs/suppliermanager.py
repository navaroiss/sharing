import os,re
os.environ['DJANGO_SETTINGS_MODULE'] = 'settings'
import settings

from django.db.models import Q
from papershare.models import PaperShareProfile, Request, RESEARCH_FIELDS,\
REQ_STA_ASSIGNED, REQ_STA_FAILED, REQ_STA_LASTCHANCE, REQ_STA_PENDING, REQ_STA_REASSIGNED, REQ_STA_SUPPLIED, REQ_STA_THANKED


i = 0
def setup():
    global i
    suppliers = PaperShareProfile.objects.filter(is_supplier=1)
    for item in suppliers:
        if item.user.username == 'navaroiss':
            print "Username: " + item.user.username
            print "Ngay dang tham gia: " + str(item.user.date_joined) 
            print "Ngay dang nhap gan day: " + str(item.user.last_login)
            print "So bai bao duoc phan cong: " + str(Request.objects.filter(supplier=item.user.id).count())
            
            SUPPLIED_STATUS = [REQ_STA_SUPPLIED, REQ_STA_THANKED]
            BAD_STATUS = [REQ_STA_PENDING, REQ_STA_ASSIGNED, REQ_STA_REASSIGNED, REQ_STA_LASTCHANCE]

            m =re.compile(';%s;' % item.user.username)
            findstring = lambda x: m.search(x)
            
            print "So bai bao hien dang tre: " + str(Request.objects.filter(Q(supplier=item.user.id),Q(status__in=BAD_STATUS)).count())        
            
            x,y = 0,0 # x la so bai bao dc xu ly boi supplier khac, y la so bai bao da cung cap
            for raw in Request.objects.filter(Q(previously_assigned__contains=item.user.username)):
                if raw.previously_assigned.split(';')[1] != item.user.username:
                    x = x + 1
                if findstring(raw.previously_assigned): 
                    y = y +1
                    
            print "So bai bao da duoc xu ly boi supplier khac: " + str(x)
            print "So bai bao da cung cap: " + str(y)
            
            print "So bai bao hien dang cho: " + str(Request.objects.filter(Q(status__in=[REQ_STA_PENDING])).count())
            
            i = i + 1
            print "========================="
    #print "Tong so supplier: " + str(i) 

def reinitialize_filter(filters):
    result = []
    default_list_filter = RESEARCH_FIELDS
    for item in filters:
        value = [ x[1] for x in default_list_filter if x[0]==item['research_field'] ]
        print value
        #result.append({item['research_field']:value[0]})
    return result
    
if __name__ == "__main__":
    filters = PaperShareProfile.objects.values('research_field').distinct()
    print reinitialize_filter(filters)