from distutils.core import setup

setup(name="stripogram",
      version="1.2",
      description="Strip-o-Gram HTML Conversion Library",
      author="Chris Withers",
      author_email="chrisw@nipltd.com",
      url="http://www.zope.org/Members/chrisw/StripOGram",
      package_dir = {"stripogram": "."},
      packages=['stripogram']
     )
