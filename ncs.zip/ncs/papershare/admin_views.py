from django.shortcuts import render_to_response
from django.contrib.auth.models import User
from ncs.papershare.models import PaperShareProfile
from django.contrib.admin.views.decorators import staff_member_required

def supplier(request):
    template_name= 'papershare/admin/papershare/change_list.html'
    supplier_list = PaperShareProfile.objects.filter(is_supplier=1)
    return render_to_response(template_name, {'supplier_list':supplier_list})
supplier = staff_member_required(supplier)