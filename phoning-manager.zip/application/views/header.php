<?php
 
/**
 * $Id: Nov 5, 2009 10:46:46 AM navaro $
 *
 */
?> 
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<title>BDD Phoning manager</title>

<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/media/css/base.css" />
<!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/media/css/ie.css" /><![endif]-->
<meta name="robots" content="NONE,NOARCHIVE" />
<script src="<?php echo base_url()?>media/js/jquery-1.3.2.min.js"></script>

<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/media/css/dashboard.css" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/media/css/forms.css" />