<?php

/**
 * $Id: Nov 4, 2009 11:04:29 PM navaro $
 * 
 */
 
class store extends Controller
{
	function store()
	{
		parent::Controller();
		$this->load->model('xmlparam');
		$this->load->helper('excel');
	}
	
	function index()
	{
		redirect('store/showing');
	}
	
	function update()
	{
		$row_id = $this->uri->segment(3);
		$row_data = $this->xmlparam->get_row($row_id);
		$inputs = input_define($row_data[0]->sql);
		$extra_data = array(
			'row'=>$row_data[0],
			'row_id'=>$row_id,
			'param_fields'=>$inputs
		);
		
		$this->load->view('store-update',
			array_merge(
				array(
						'username'=>$this->session->userdata('uname'),
				), 
				$extra_data
			)
		);
	}
	
	function remove()
	{
		$row_id = $this->uri->segment(3);
		if(is_numeric($row_id))
		{
			$this->xmlparam->delete($row_id);
		}
		redirect('store/showing');
	}
	
	function showing()
	{
		$extra_data = array(
			'xml_rows'=>$this->xmlparam->get_rows()
		);
		
		$this->load->view('store-showing',
			array_merge(
				array(
						'username'=>$this->session->userdata('uname'),
				), 
				$extra_data
			)
		);
	}
	
	function adding()
	{
		$extra_data = array();
		
		if(count($_FILES)>=1)
		{
			$config['upload_path'] = FCPATH.'/reports/';
			$config['allowed_types'] = 'xml';
			$config['max_size']	= '100';
			$this->load->library('upload', $config);
			if ( ! $this->upload->do_upload('xmlfile'))
			{
				redirect('/report/index/');//print_r($this->upload->display_errors());
			}	
			else
			{
				$upload_data = $this->upload->data();
				$data = handle_xml($upload_data['full_path']);
				if(count($data)>=1){
					$inputs = input_define($data[0]['content']['SQL']);
				}				
				
				$store = new stdClass();
				$store->filename = $upload_data['file_name'];
				$store->username = $this->session->userdata('uname');
				$store->datetime = date("Y-m-d H:m:s");
				$store->sql 	 = $data[0]['content']['SQL'];
				$store->title 	 = $data[0]['content']['title'];
				if(isset($data[0]['content']['action']))
					$store->action 	 = $data[0]['content']['action'];
				else
					$store->action 	 = '';
				
				$this->xmlparam->insertObj($store);
				$last_insert_id = $this->xmlparam->db->insert_id();
				$extra_data = array(
					'last_insert_id'=>$last_insert_id,
					'inputs'=>$inputs,
					'sql'=>$data[0]['content']['SQL']
				);
			}		
		}
		
		if(count($_POST)>=1)
		{
			$fields = array();
			if(count($this->input->post('param'))>=1){
				$params = $this->input->post('param');
				$last_insert_id = $this->input->post('last_insert_id');
				if($last_insert_id==0)
				{
					if($this->uri->segment(3)>=1)
					{
						$last_insert_id = $this->uri->segment(3);	
					}
				}
				if(count($params)>=1 && is_array($params))
				{
					foreach($params as $k=>$v)
					{
						$fields[] = "PARAM.$k=".$params[$k];
					}
				}
			}
			$this->xmlparam->updateRow($last_insert_id, array('fields'=>implode(';', $fields)));			
		}

		$this->load->view('store-adding',
			array_merge(
				array(
						'username'=>$this->session->userdata('uname'),
				), 
				$extra_data
			)
		);
		
	}
}