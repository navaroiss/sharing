<?php

/**
 * $Id: Sep 14, 2009 2:53:10 PM navaro $
 * 
 */

include_once('xml-simple.php');
include_once('excelwriter.php');
//include_once('specialreport.php');

function fetch_xml_title($file)
{
	$data = handle_xml($file);
	if(count($data)>=1)
		return $data[0]['content']['title'];
	else
		return false;	
}
function listTableFields($field_name='', $select_table_field="")
{
	$GLOBALS['CI']->load->database('');
	$html = "";
	$tables = $GLOBALS['CI']->db->list_tables();
	if(count($tables)>=1)
	{
		$html = "<select name='$field_name'>";
		foreach($tables as $k=>$table_name)
		{
			$table_fields = $GLOBALS['CI']->db->list_fields( $table_name );
			if(count($table_fields)>=1)
			{
				foreach($table_fields as $k=>$table_field_name)
				{
					if($select_table_field == $table_name.".".$table_field_name)
					{
						$selected = "selected='selected'";
					}else{
						$selected = "";
					}
					$html .= "<option $selected value='".$table_name.".".$table_field_name."'>".$table_name.".".$table_field_name."</option>";
				}
			}
		}
		$html .= "</select>";
	}
	return $html;
}

function handle_xml($file="")
{
	if(is_file($file))
		$content = @file_get_contents( $file );
	else
		$content = @file_get_contents( $_FILES['xmlfile']['tmp_name'] );
	@$parser =& new xml_simple('UTF-8');
	@$parser->parse($content);
	return $parser->tree;
}

function fetch_db($sql)
{
	$GLOBALS['CI']->load->database('');
	$query = $GLOBALS['CI']->db->query($sql);
	return $query->result();
}

function input_define($sql, $values=array())
{
	if(preg_match_all('|\[PARAM\.(\d+)\]|', $sql, $matches))
	{
		$i = 0; 
		foreach($matches[1] as $k=>$v)
		{
			$value_selected = (isset($values[$i]))?$values[$i]:"";
			$inputs[$v] = listTableFields("param[$v]", $value_selected);
			$i++;
		}
	}
	return $inputs;
}

function input_value($fieldname=array(), $name="", $value_selected="")
{
	$values = fetch_db("select distinct ".$fieldname[1]." from ".$fieldname[0]." order by ".$fieldname[1]." DESC");
	$html = "";
	if(count($values)>=1)
	{
		$name = explode(".", $name);
		$html = "<select name='".strtolower($name[0])."[".$name[1]."]'>";
		foreach( $values as $k=>$v)
		{
			if($value_selected == $v->$fieldname[1])
			{
				$selected = "selected='selected'";
			}else{
				$selected = "";
			}
			$html .= "<option $selected value='".$v->$fieldname[1]."'>".$v->$fieldname[1]."</option>";		
		}
		$html .= "</select>";
	}
	return $html;
}

function export_as($sql, $params=array(), $filename='excel_report.xls')
{
	if(count($params)>=1)
	{
		foreach($params as $k=>$v)
		{
			$value = (is_numeric($v))?$v:"'".$v."'";
			$sql = str_replace("[PARAM.$k]", $value, $sql);
		}
	}
	//die($filename);
	//$filename = str_replace('.xml', '.xls', $filename);
	$data = fetch_db($sql);
	safe_file_as( $data, $filename ); //trim($data[0]['content']['templatename']
	if(is_file(FCPATH."reports/".$filename))
	{
		#@chmod("/somedir/somefile", 777);
		return array($filename, count($data));
	}
	return false;
}

function ConvertToQuery($sql, $params=array())
{
	if(count($params)>=1)
	{
		foreach($params as $k=>$v)
		{
			$value = (is_numeric($v))?$v:"'".$v."'";
			$sql = str_replace("[PARAM.$k]", $value, $sql);
		}
	}
	return $sql;
}
function RevertString($string)
{
	return str_replace("_*", "", $string);
}
function colName($coln)
{
	$alpha = array();
	for($i=0;$i<=25;$i++)
	{
		$basic[$i] = chr($i+65);		
	}
	if($coln<=25)
	{
		return $basic[$coln-1]; 
	}else
	{
		for($i=0;$i<=count($basic)-1;$i++)
		{
			$a=$basic[$i];
			for($x=0;$x<=count($basic)-1;$x++)
			{
				$b=$basic[$x];
				$store[] = "$a$b";
			}
		}
		return $store[$coln-1];
	}
}
function safe_file_as($data, $filename='excel_report.xml')
{
	// The old solution
  	// wbWriter($data, $filename); // Call the new excel writer system.
	
	
	require_once FCPATH.'includes/Classes/PHPExcel.php';
	require_once FCPATH.'includes/Classes/PHPExcel/IOFactory.php';
	
	$objPHPExcel = new PHPExcel();
	// 65 -> 90 = A -> Z
	$i=1;
	$x=65;
	//print_r($data);
	if(count($data)>=1)
	{
		foreach($data as $k=>$v)
		{
			$x=65;
			foreach($v as $k=>$vl)
			{
				if($i==1)
				{
		            $objPHPExcel->setActiveSheetIndex(0)->setCellValue(chr($x)."$i", $k);
					$objPHPExcel->setActiveSheetIndex(0)->getStyle(chr($x)."$i")->getFont()->setSize(15);
					$objPHPExcel->setActiveSheetIndex(0)->getStyle(chr($x)."$i")->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLUE);
					$objPHPExcel->getActiveSheet()->getStyle(chr($x)."$i")->applyFromArray(
							array(
								'font'    => array(
									'bold'      => true
								),
								'alignment' => array(
									'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
								),
								'borders' => array(
									'top'     => array(
					 					'style' => PHPExcel_Style_Border::BORDER_THIN
					 				)
								),
								'fill' => array(
						 			'type'       => PHPExcel_Style_Fill::FILL_GRADIENT_LINEAR,
						  			'rotation'   => 90,
						 			'startcolor' => array(
						 				'argb' => 'FFA0A0A0'
						 			),
						 			'endcolor'   => array(
						 				'argb' => 'FFFFFFFF'
						 			)
						 		)
							)
					);			}else{
					$objPHPExcel->setActiveSheetIndex(0)->setCellValue(chr($x)."$i", $vl);
				}
				//echo chr($x)."$i, $k";
				$x++;
			}
			$i++;
		}
		
	}

	$objPHPExcel->getActiveSheet()->setAutoFilter("A1:".chr($x).($i-1));		
	$objPHPExcel->getActiveSheet()->setTitle('Phoning manager');		
	$objPHPExcel->setActiveSheetIndex(0);
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	$objWriter->save(FCPATH."reports/rs.xlsx");  		
}

function HeaderingExcel($filename) {
      header("Content-type: application/vnd.ms-excel");
      header("Content-Disposition: attachment; filename=$filename" );
      header("Expires: 0");
      header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
      header("Pragma: public");
}

function wbWriter($data, $filename) // Workbook writer
{
  include_once(FCPATH.'includes/excelwriter/Worksheet.php');
  include_once(FCPATH.'includes/excelwriter/Workbook.php');
    
  HeaderingExcel($filename);
	
  $workbook = new Workbook("-");

  $worksheet =& $workbook->add_worksheet('Phoning manager'); // worksheet 1
  
  $format_title =& $workbook->add_format(); // Format for the headings
  $format_title->set_size(11);
  $format_title->set_align('center');
  $format_title->set_color('white');
  $format_title->set_pattern();
  $format_title->set_fg_color('green');
  $format_title->set_bold();
  
  $format_cells =& $workbook->add_format(); // Format for the cells
  $format_cells->set_size(10);
  $format_cells->set_align('left');
  $format_cells->set_color('black');
  $format_cells->set_pattern();
  $format_cells->set_fg_color('gray');
  $format_cells->set_border(1);
  
  //print_r($data);
  
  $i=0;
  foreach($data as $k=>$v)
  {
  	$y=0;
	foreach($v as $k=>$vl)
	{
		if($i==0)
		{
			$worksheet->write_string($i, $y, $k, $format_title);	
		}else{
			$worksheet->write_string($i, $y, $vl, $format_cells);
		}
	  	$y++;
	}
	$i++;
   }
  
   $workbook->close();	
}

?>
