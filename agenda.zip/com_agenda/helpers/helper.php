<?php
/*
 * $Id: Jul 4, 2009 4:45:22 PM navaro  $
 *  
 */
	require_once('calendar.php');
	
	function showCalendar()
	 {
		$calendar = new Calendar ('2000', '2');
		$calendar->setTableWidth('50%');
		//$calendar->setDayNameFormat('%A');
		echo "<b>".$calendar->getBriefMonthName()."</b>";
		echo $calendar->display();  	
	 }
?>
