<?php
/*
 * $Id: Jul 6, 2009 3:08:11 PM navaro  $
 *  
 */
 jimport('joomla.application.component.model');
 class AgendaModelEvent extends JModel
 {
 	
 	function getEventsMonth($month, $year, $other_date_data=array())
 	{
 		 $db =& JFactory::getDBO();
 		 $user =& JFactory::getUser();
 		 $condition = $this->getUserRfc();//return string
 		 
 		 if(count($other_date_data)==0){
	 		 $db->setQuery("SELECT #__agenda_events.*, #__agenda_categories.id as cid, #__agenda_categories.icon as c_icon FROM #__agenda_events
							inner join #__agenda_categories on #__agenda_categories.id = #__agenda_events.cat_id
	 		 							where (`end_date` >= '$year-$month-01' and `start_date` <= '$year-$month-31') $condition
							order by #__agenda_events.start_date DESC");
 		 }else{
 		 	$start_date = $other_date_data['start']['year']."-".$other_date_data['start']['month']."-".$other_date_data['start']['day'];
 		 	$end_date = $other_date_data['end']['year']."-".$other_date_data['end']['month']."-".$other_date_data['end']['day'];
 		 	if($other_date_data['next']==true){
 		 		$where = "where (`end_date` >= '$end_date' and `start_date` <= '$start_date')";
 		 	}elseif($other_date_data['prev']==true){
 		 		$where = "where (`end_date` >= '$start_date' and `start_date` <= '$end_date')";
 		 	}
	 		$db->setQuery("SELECT #__agenda_events.*,#__agenda_categories.id as cid, #__agenda_categories.icon as c_icon FROM #__agenda_events
							inner join #__agenda_categories on #__agenda_categories.id = #__agenda_events.cat_id
	 		 				 $where $condition
							order by #__agenda_events.start_date DESC");
 		 }
 		 //echo $db->getQuery();
 		 return $db->loadObjectList();
 	}
 	
 	function getDaysMonth()
 	{
 		$month_30_days = array(4,6,9,11);
 	}
 	
 	function loadEvent($event_id)
 	{
 		$db =& JFactory::getDBO();
 		$event_id = (int) $event_id;
 		$db->setQuery("SELECT #__agenda_events.*, #__agenda_categories.name, #__agenda_categories.id as cid,						#__agenda_categories.description as d, #__agenda_categories.icon as c_icon
 							FROM #__agenda_events left join #__agenda_categories
 						 	on #__agenda_events.cat_id = #__agenda_categories.id 
 						 	where #__agenda_events.id = $event_id"); //echo $db->getQuery();
 		return $db->loadObject();
 	}
 	
 	function searchKeyword($key, $advance=false, $cr=array())
 	{
 		$db =& JFactory::getDBO();
		
 		$condition = $this->getUserRfc();//return string
 		
 		if($advance==false){
	 		$db->setQuery("SELECT #__agenda_events.*,  #__agenda_categories.name, #__agenda_categories.id as cid
	 							 FROM #__agenda_events left join #__agenda_categories 
	 							 on #__agenda_events.cat_id = #__agenda_categories.id   
	 							 where (#__agenda_events.title like '%{$key}%' or 
	 							 #__agenda_events.description like '%{$key}%' or 
	 							 #__agenda_events.content like '%{$key}%') $condition
								 order by #__agenda_events.start_date DESC");
 		}else{
 			$fmc = $cr['fmc']==1?1:0;
 			$from_month = $cr['from_month'];
 			$from_year = $cr['from_year'];
 			$to_month = $cr['to_month'];
 			$to_year = $cr['to_year'];
	 		$db->setQuery("SELECT #__agenda_events.*,  #__agenda_categories.name, #__agenda_categories.id as cid
	 							 FROM #__agenda_events left join #__agenda_categories 
	 							 on #__agenda_events.cat_id = #__agenda_categories.id   
	 							 where (#__agenda_events.title like '%{$key}%' or 
	 							 #__agenda_events.description like '%{$key}%' or 
	 							 #__agenda_events.content like '%{$key}%') 
	 							 and #__agenda_events.start_date >= '$from_year-$from_month-01'
	 							 and #__agenda_events.end_date <= '$to_year-$to_month-31'
	 							 and #__agenda_events.fmc = $fmc $condition
								 order by #__agenda_events.start_date DESC");
	 					//echo $db->getQuery();die();
 		}
		//echo $db->getQuery();
 		return $db->loadObjectList();
 	}
 	
 	function loadCat($cat, $field=null)
 	{
 		$db =& JFactory::getDBO();
 		$cat = (int) $cat;
 		$db->setQuery("SELECT * from #__agenda_categories where id = $cat"); //echo $db->getQuery();
 		if($field!=null){
 			$tmp = $db->loadObject();
 			return $tmp->$field;
 		}
 		return $db->loadObject();
 	}
 	
 	function loadEventCat($cat)
 	{
 		$db =& JFactory::getDBO();

 		$condition = $this->getUserRfc();//return string
 		 		 		
 		$db->setQuery("select #__agenda_events.*, #__agenda_categories.name from #__agenda_events 
						inner join #__agenda_categories on #__agenda_events.cat_id = #__agenda_categories.id
						where #__agenda_events.cat_id = $cat $condition
						order by #__agenda_events.start_date DESC");
						//echo $db->getQuery();
 		return $db->loadObjectList();
 	}
 	
 	function getUserRfc()
 	{
 		$user =& JFactory::getUser();
 		$db =& JFactory::getDBO();
 		global $agenda_config;
 		$condition = '';
 		
 		if( $user->get('id') >= 1 )
 		{
 			$registered_view_registered = $agenda_config->get('registered_view_event_registered', 'value');
 			$registered_view_public = $agenda_config->get('registered_view_event_public', 'value');
 			$condition .= ($registered_view_registered==2)?" and (#__agenda_events.public = 2":" and (#__agenda_events.public = -1";
 			$condition .= ($registered_view_public==1)?" or #__agenda_events.public = 1)":" or #__agenda_events.public = -1)";

 			/*
 			 * Don't remove below lines, please Monsieur.
 			 * There lines lets define which categorys will use.
 			 * $view_event_public = $agenda_config->get('registered_view_event_public', 'value');
 			 * $user_id = $user->get('id');
 			 * $db->setQuery("select `params` as tt from #__agenda_uf where user_id = $user_id");
 			 * $result = $db->loadResult();
 			 * $condition .= ($db->loadResult()!='')?" and #__agenda_events.cat_id in ($result)":" and #__agenda_events.cat_id < 0";
 			 */
 			
 		}else{
 			$guest_view = $agenda_config->get('guest_view', 'value');
			$condition = ($guest_view==1)?' and #__agenda_events.public = 1':' and #__agenda_events.public = -1';
			
			/*
			 * And don't remove below codes.
			 * $session =& JFactory::getSession();
			 * $db->setQuery("select id from #__agenda_categories");
			 foreach($db->loadObjectList() as $k=>$v)
			 {
				$default_cats[] = $v->id;
			 }
			 * $cats = strlen($session->get('uf'))>=1?$session->get('uf'):implode(',', $default_cats);
			 * $condition .= " and #__agenda_events.cat_id in ($cats) ";
			*/
 		}
 		return $condition; 
 	}

	function getChilds($cat_id)
	{
		$db =& JFactory::getDBO();
		$sql = "select * from #__agenda_categories where parent=$cat_id order by name";
		$db->setQuery($sql);
		return $db->loadObjectList();
	}
	
	function getOtherEventDay($current_month, $current_year)
	{
		$prev_start = array();
		$next_start = array();
		
		if($current_month>=2){
			$prev_start['month'] = $current_month-1;
			$prev_start['year'] = $current_year;
		}else{
			$prev_start['month'] = 12;
			$prev_start['year'] = $year-1;
		}
		
		$month_days_prev = $this->getMonthDays($prev_start['month'], $prev_start['year']);
		
		if($current_month<=11){
			$next_start['month'] = $current_month+1;
			$next_start['year'] = $current_year;
		}else{
			$next_start['month'] = 1;
			$next_start['year'] = $current_year+1;
		}
		$month_days_next = $this->getMonthDays($next_start['month'], $next_start['year']);
		
		$a = $n = 0;
		$w = array("Sun","Mon","Tue","Wed","Thu","Fri","Sat");
		$first_d = date("D", strtotime("$current_year-$current_month-01"));
		foreach($w as $k=>$d)
		{
			if($d==$first_d) {
				$n = $a;
				break;
			}
			$a++; 
		}
		
		$prev_start['day'] = $month_days_prev - $n + 1;
		$prev_end['day'] = $month_days_prev;
		$prev_end['month'] = $prev_start['month'];
		$prev_end['year'] = $prev_start['year'];
		$datedata['start'] = $prev_start;
		$datedata['end'] = $prev_end;
		$datedata['prev'] = true;
		$prev_events = $this->getEventsMonth($current_month, $current_year, $datedata);
		
		$month_days = $this->getMonthDays($current_month, $current_year);
		$last_d = date("D", strtotime("$current_year-$current_month-$month_days"));
		$a = $n = 0;
		foreach($w as $k=>$d)
		{
			if($d==$last_d){
				$n = $a;
				break;
			}
			$a++; 
		}
		$next_start['day'] = 1;
		$next_end['day'] = 6-$n;
		$next_end['month'] = $next_start['month'];
		$next_end['year'] = $next_start['year'];
		$datedata['start'] = $next_end;
		$datedata['end'] = $next_start;
		$datedata['next'] = true;
		$next_events = $this->getEventsMonth($current_month, $current_year, $datedata);
		
		$data = array();
		$data['prev_event']['event'] = $prev_events;
		$data['prev_event']['date']['start'] = $prev_start;
		$data['prev_event']['date']['end'] = $prev_end;
		$data['next_event']['event'] = $next_events;
		$data['next_event']['date']['start'] = $next_start;
		$data['next_event']['date']['end'] = $next_end;
		return $data;	
	}
	 function getMonthDays($month, $year)
	{
		$month_30_days = array(4,6,9,11);
		$month_days = 31;
		
		if( ($year%4==0 && $year%100!=0) || ($year%400==0) ){
			$leap_year = true;
		}
		
		if(in_array($month, $month_30_days)){
			$month_days = 30;
		}elseif($month==2)
		{
			$month_days = ($leap_year==true)?29:28;	
		}
		return $month_days;
	}
  }
?>
