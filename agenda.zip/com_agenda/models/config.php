<?php
/*
 * $Id: Jul 8, 2009 2:32:44 PM navaro  $
 *  
 */
 jimport('joomla.application.component.model');
 class AgendaModelConfig extends JModel
 {
 	function get($name, $returnf=null)
 	{
 		$db =& JFactory::getDBO();
 		$db->setQuery("select * from #__agenda_config where `name`='$name'"); //echo $db->getQuery();
		if(!$returnf){
 			return $db->loadObject();	
 		}else{
 			$tmp = $db->loadObject();//print_r($tmp);
 			return $tmp->$returnf;
 		}
 		
 	}
 }
?>