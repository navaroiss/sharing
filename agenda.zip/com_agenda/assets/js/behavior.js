var $j = jQuery.noConflict();

this.list_witch = function()
{
	var listclicked = 0; // hidden
	$j('#click-bt').click(function(e){
		if(listclicked==0)
		{
			listclicked=1;
			$j('#table-list-event').slideDown();
		}else{
			listclicked=0;
			$j('#table-list-event').slideUp();
		}
	})
}

$j(document).ready(function(){
	list_witch();
});