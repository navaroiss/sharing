 <div class="component-header"> <h1 class="componentheading" style="visibility: visible;"><span><?=JText::_('AGENDA')?></span> </h1></div>
 
 <?php echo $this->cat_info->name?>
<hr/>
 <?php echo $this->cat_info->description?>
<br/><br/>
<table width="100%" cellspacing="5" cellpadding="5">
<? 
	$total = count($this->cats);
	$i=1;
	foreach($this->cats as $k=>$v)
	{
		if(($i+1)%2==0)
			echo '<tr>';
?>
		<td class="rec" width="50%">
		<div><a href="index.php?option=com_agenda&task=listevent&cat=<?=$v->id?>"><?=$v->name?></a></div>
		<div><?=$v->description?></div>
		</td>
<?
		$i++;
	}
?>
</table>
<br/><br/>
 <?php
 if(count($this->events)>=1){
?>
Acticles:
<hr/>
<table width="100%" cellpadding="0" cellspacing="0">
<? 
 foreach($this->events as $k=>$v)
 {
 ?>
 	<tr>
 		<td>
		<?=date('d-m-Y', strtotime($v->start_date))?>
		- 
 		<a class="a_underline" href="<?php echo "index.php?option=com_agenda&task=view&event={$v->id}&Itemid={$Itemid}"?>">
 			<?php echo $v->name." - ".$v->title?>
 		</a>

 		</td>
 	</tr>
 <?	
 }
?>
</table>
<? } ?>
