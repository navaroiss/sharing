<?php
/*
 * $Id: Jul 9, 2009 2:13:00 AM navaro  $
 *  
 */

 global $Itemid;

 ?>
  <div class="component-header"> <h1 class="componentheading" style="visibility: visible;"><span><?=JText::_('AGENDA')?></span> </h1></div>
  
 <?php echo $this->cat_info->name?>
<hr/>
 <?php echo $this->cat_info->description?>
 <?php
 if(count($this->events)>=1){
?>
<br/><br/>
Acticles:
<hr/>
<table width="100%" cellpadding="0" cellspacing="0">
<? 
 foreach($this->events as $k=>$v)
 {
 ?>
 	<tr>
 		<td>
		<?=date('d-m-Y', strtotime($v->start_date))?>
		- 
 		<a class="a_underline" href="<?php echo "index.php?option=com_agenda&task=view&event={$v->id}&Itemid={$Itemid}"?>">
 			<?php echo stripcslashes($v->name." - ".$v->title)?>
 		</a>

 		</td>
 	</tr>
 <?	
 }
?>
</table>
<? } ?>
