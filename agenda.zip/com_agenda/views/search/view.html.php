<?php
/*
 * $Id: Jul 9, 2009 2:11:02 AM navaro  $
 *  
 */
 jimport('joomla.application.component.view');
 class AgendaViewSearch extends JView
 {
 	function display($tmp = null)
 	{
		global $mainframe;
 		$doc =& JFactory::getDocument();
 		$doc->addStyleSheet( JURI::root().'/components/com_agenda/assets/css/agenda.calendar.css' );
		$pathway =& $mainframe->getPathway();
		$pathway->addItem( 'Calendar', "index.php?option=com_agenda&task=calendar" );
		parent::display($tmp);
 	}
 }
?>