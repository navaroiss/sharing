<?php
/*
 * $Id: Jul 6, 2009 2:59:07 PM navaro  $
 *  
 */
function getMonthDays($month, $year)
{
	$month_30_days = array(4,6,9,11);
	$month_days = 31;
	
	if( ($year%4==0 && $year%100!=0) || ($year%400==0) ){
		$leap_year = true;
	}
	
	if(in_array($month, $month_30_days)){
		$month_days = 30;
	}elseif($month==2)
	{
		$month_days = ($leap_year==true)?29:28;	
	}
	return $month_days;
}


$year = $this->year;
$month = $this->month;
$today = date('d');
$current_month = date('m');

$month_days = getMonthDays($month, $year);
if($month>=2){
	$month_days_prev = getMonthDays($month-1, $year);
}else{
	$month_days_prev = getMonthDays(12, $year-1);
}
if($month<=11){
	$month_days_next = getMonthDays($month+1, $year);
}else{
	$month_days_next = getMonthDays(1, $year+1);
}

$py = $ny = $year;
$content='';
$w = array("Sun","Mon","Tue","Wed","Thu","Fri","Sat");
$shtml = "<td class='%s' valign='top'><span>%s</span><div class='ect'>%s</div></td>" ;
$default_tdcss = '';
$first_d = date("D", strtotime("$year-$month-01"));
$n=$a=$cols = 0;
$url = 'index.php?option=com_agenda&';
$lang = JRequest::getVar('lang');
global $Itemid;
$month_array = array("JANUARY", "FEBRUARY", "MARCH", "APRIL",
	"MAY", "JUNE", "JULY", "AUGUST", 
	"SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER");

$sort_month_array = array("JAN", "FEB", "MAR", "APR",
	"MAY", "JUN", "JUL", "AUG", 
	"SEP", "OCT", "NOV", "DEC");

if($month>=2){
	$prev['month'] = $month-1;
}else{
	$prev['month'] = 12;
	$py = $year - 1;
}
$prev['year'] = $year-1;

if($month<=11){
	$next['month'] = $month+1;
}else{
	$next['month'] = 1;
	$ny = $year + 1;
}
$next['year'] = $year+1;


?>