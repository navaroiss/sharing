<?php
/*
 * $Id: Jul 9, 2009 3:57:46 PM navaro  $
 *
 */
// echo $array;


?>
<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery("#checkchildren").checkboxTree({
			collapsedarrow: "<?php echo JURI::root().'components/com_agenda/assets/'?>images/checkboxtree/img-arrow-collapsed.gif",
			expandedarrow: "<?php echo JURI::root().'components/com_agenda/assets/'?>images/checkboxtree/img-arrow-expanded.gif",
			blankarrow: "<?php echo JURI::root().'components/com_agenda/assets/'?>images/checkboxtree/img-arrow-blank.gif",
			checkchildren: true
	});
});
</script>


<form action="" method="post">
	<ul class="unorderedlisttree" id="checkchildren">
		<?php echo $combox?> 
	</ul>
	<!-- 
	<input type="hidden" name="user_rfc" value="1"> 
	<input style="width: 100px;" type="submit" name="sm" value="<?php echo JTEXT::_('APPLY')?>">
	 -->
</form>
