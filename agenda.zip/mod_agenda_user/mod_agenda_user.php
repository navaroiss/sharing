<?php
/*
 * $Id: Jul 9, 2009 3:52:04 PM navaro  $
 *
 */
include(dirname(__FILE__).DS.'helper.php');
$db =& JFactory::getDBO();
$conf =& JFactory::getConfig();
$user =& JFactory::getUser();
$ids = JRequest::getVar('id', '', 'post', 'array');
$user_rfc = JRequest::getVar('user_rfc', 0, 'post', 'int');

mysql_connect($conf->getValue('config.host'), $conf->getValue('config.user'), $conf->getValue('config.password'));
mysql_select_db($conf->getValue('config.db'));

$db->setQuery("select value from #__agenda_config where `name`='icon_path'");
$icon_path = $db->loadResult();

$db->setQuery("select value from #__agenda_config where `name`='save_uf_by'");
$save_uf_by = $db->loadResult();

if($save_uf_by=='db_table'){
	if($user->get('id')>=1){
		$user_id = $user->get('id');
		$db->setQuery("select count(*) as tt from #__agenda_uf where `user_id` = $user_id");
		$data_count = $db->loadResult(); //echo $db->getQuery();
		$str_params = implode(',', $ids);
		$temp = new stdClass;
		$temp->user_id = $user->get('id');
		$temp->params = $str_params;
		$prefix = $conf->getValue('config.dbprefix');
		$sql = "select * from ".$prefix."agenda_categories order by name ASC";
		$db->setQuery($sql);
		$result_sync = $db->loadObjectList();
		$result =  mysql_query($sql);
		$array = new AdvanceTvs($result, $result_sync, $icon_path);
		if(count($_POST)>=1 && $user_rfc==1){
			if($data_count>=1){
				$db->updateObject('#__agenda_uf', $temp, 'user_id');
			}else{
				$db->insertObject('#__agenda_uf', $temp);
			}
		}
		$db->setQuery("select `params` as tt from ".$prefix."agenda_uf where `user_id` = $user_id");
		$combox = $array->getDropDownList( explode(',', $db->loadResult()) );
	}else{
		$session =& JFactory::getSession();
		if(count($_POST)>=1 && $user_rfc==1){
			$cookies = implode(',', $_POST['id']);
			$session->set('uf', $cookies);
		}
		$prefix = $conf->getValue('config.dbprefix');
		$sql = "select * from ".$prefix."agenda_categories";
		$db->setQuery($sql);
		$result_sync = $db->loadObjectList();
		$result =  mysql_query($sql);
		$array = new AdvanceTvs($result, $result_sync, $icon_path);
		foreach($result_sync as $k=>$v)
		{
			$default_cats[] = $v->id;	
		}
		$cats = strlen($session->get('uf'))>=1?$session->get('uf'):implode(',',$default_cats);
		$combox = $array->getDropDownList( explode(',', $cats) );
	}
}else{
	$session =& JFactory::getSession();
	if(count($_POST)>=1 && $user_rfc==1){
		$cookies = implode(',', $_POST['id']);
		$session->set('uf', $cookies);
	}
	$db->setQuery("select id from #__agenda_categories where selected_by_default=1");
	$results = $db->loadObjectList();
	if(strlen($session->get('uf'))>=1)
	{
		$cats = explode(',', $session->get('uf'));
	}else{
		$cats = array();
		foreach($results as $k=>$v)
		{
			$cats[] = $v->id;
		}
	}
	$prefix = $conf->getValue('config.dbprefix');
	$sql = "select * from ".$prefix."agenda_categories order by name ASC";
	$db->setQuery($sql);
	$result_sync = $db->loadObjectList();
	$result =  mysql_query($sql);
	$array = new AdvanceTvs($result, $result_sync, $icon_path);
	$combox = $array->getDropDownList( $cats );
}

if(count($_POST)>=1 && $user_rfc==1){
	global $mainframe, $Itemid;
	foreach($_GET as $k=>$v)
		{
			$vars[] = "$k=$v";
		}
	$mainframe->redirect(JURI::root().'index.php?'.implode('&', $vars));	
}

$doc =& JFactory::getDocument();
$doc->addScript(JURI::root().'components/com_agenda/assets/js/jquery.checkboxtree.js');
$doc->addStyleSheet(JURI::root().'components/com_agenda/assets/css/checkboxtree.css');

include(JModuleHelper::getLayoutPath('mod_agenda_user'));
?>
