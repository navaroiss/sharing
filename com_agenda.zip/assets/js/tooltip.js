var $j = jQuery.noConflict();
this.ShowtoolTip = function(){
		xOffset = 10;
		yOffset = 30;
	$j("img.tickevent").hover(function(e){
		this.id = parseInt(this.id); 
		c = typeof(content[this.id])!='undefined'?"<p id='jtooltip'>"+content[this.id]+"</p>":'';	
		$j("body").append(c);								 
		$j("#jtooltip")
			.css("top",(e.pageY - xOffset) + "px")
			.css("left",(e.pageX + yOffset) + "px")
			.fadeIn("fast");						
    },
	function(){
		$j("#jtooltip").remove();
    });	
	$j("img.tickevent").mousemove(function(e){
		$j("#jtooltip")
			.css("top",(e.pageY - xOffset) + "px")
			.css("left",(e.pageX + yOffset) + "px");
	});			
};


$j(document).ready(function(){
	ShowtoolTip();
});