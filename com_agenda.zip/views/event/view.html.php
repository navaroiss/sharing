<?php
/*
 * $Id: Jul 8, 2009 1:54:14 PM navaro  $
 *  
 */
 jimport('joomla.application.component.view');
 class AgendaViewEvent extends JView
 {
 	function display($tmp=null)
 	{
 		global $mainframe, $Itemid;
 		
 		$pathway =& $mainframe->getPathway();
 		
 		if(is_object($this->event_details)){
	 		$pathway->addItem( $this->event_details->name, "index.php?option=com_agenda&task=listevent&cat={$this->event_details->cid}&Itemid={$Itemid}" );
	 		$pathway->addItem( $this->event_details->title );
 		}
 		if(isset($this->cat_info->name) && $this->cat_info->name!=''){
	 		$pathway->addItem( $this->cat_info->name );
 		}
 		$doc =& JFactory::getDocument();
 		$doc->addStyleSheet( JURI::root().'/components/com_agenda/assets/css/agenda.calendar.css' );
 		
 		parent::display($tmp);
 	}
 }
?>