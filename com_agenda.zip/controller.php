<?php
/*
 * $Id: Jul 4, 2009 4:30:37 PM navaro  $
 *  
 */
 jimport('joomla.application.component.controller');
 class AgendaController extends JController 
 {
 	function calendar()
 	{
 		global $mainframe;
 		$view = $this->getView('calendar', 'html');

 		$config = $this->getModel('config');
 		$GLOBALS['agenda_config'] = $config;
 		$model = $this->getModel('event');

 		$year = (int) ($_REQUEST['year']>=1?$_REQUEST['year']:date('Y'));
		$month = (int) ($_REQUEST['month']>=1?$_REQUEST['month']:date('m'));
 		
 		$events = $model->getEventsMonth($month, $year);
		//print_r($events);
 		foreach($events as $k=>$v)
 		{
			$event_start_day = date('d-m-Y', strtotime("$v->start_date"));
			$event_end_day = date('d-m-Y', strtotime("$v->end_date"));
			$event_day = array($event_start_day, $event_end_day);
 			$event_array['event'][$v->id] = $this->getDaysDisplayIcons($event_day, $month, $year);
			$event_array['icon'][$v->id]	= $v->icon!=''?$v->icon:$v->c_icon;
			$event_array['title'][$v->id]	= $v->title;
			$event_array['cat'][$v->id]	= $v->cid;
 		}
		//print_r($event_array);

 		$other_events = $model->getOtherEventDay($month, $year);//print_r($other_events);
 		$otherEvents = array();
 		if(count($other_events)>=1){
 			if(count($other_events['prev_event']['event'])>=1){
		 		foreach($other_events['prev_event']['event'] as $k=>$v)
		 		{
					$event_start_day = date('d-m-Y', strtotime("$v->start_date"));
					$event_end_day = date('d-m-Y', strtotime("$v->end_date"));
					$event_day = array($event_start_day, $event_end_day);
					$start = $other_events['prev_event']['date']['start'];
					$end = $other_events['prev_event']['date']['end'];
					$otherEvents['prev']['event'][$v->id] = $this->getDaysDisplayIcons($event_day, $month, $year, $start, $end);
					$otherEvents['prev']['icon'][$v->id]	= $v->icon!=''?$v->icon:$v->c_icon;
					$otherEvents['prev']['title'][$v->id]	= $v->title;
					$otherEvents['prev']['cid'][$v->id]	= $v->cid;
		 		}
 			}
 			if(count($other_events['next_event']['event'])>=1){
 				foreach($other_events['next_event']['event'] as $k=>$v)
		 		{
					$event_start_day = date('d-m-Y', strtotime("$v->start_date"));
					$event_end_day = date('d-m-Y', strtotime("$v->end_date"));
					$event_day = array($event_start_day, $event_end_day);
		 			$start = $other_events['next_event']['date']['start'];
					$end = $other_events['next_event']['date']['end'];
					//print_r($other_events['next_event']['date']);die();
					$otherEvents['next']['event'][$v->id] = $this->getDaysDisplayIcons($event_day, $month, $year, $start, $end);
					$otherEvents['next']['icon'][$v->id]	= $v->icon!=''?$v->icon:$v->c_icon;
					$otherEvents['next']['title'][$v->id]	= $v->title;
					$otherEvents['next']['cid'][$v->id]	= $v->cid;
		 		}
 			}
 		}
		//print_r($otherEvents['prev']);
 		$view->assign('icon_path', $config->get('icon_path', 'value'));
 		$view->assign('year', $year);
 		$view->assign('month', $month);
 		$view->assignRef('events', $event_array);
 		$view->assignRef('agenda_config', $config);
 		$view->assignRef('other_events', $otherEvents);//print_r($otherEvents);
 		$view->display();
 	}
 	
	function getDaysDisplayIcons($event_day, $month, $year, $start=array(), $end=array())
	{
		if(count($start)==0){
			$start = explode('-', "1-$month-$year");
		}else{
			$start[0] = $start['day'];
			$start[1] = $start['month'];
			$start[2] = $start['year'];
		}
		if(count($end)==0){
			$end = explode('-', "31-$month-$year");
		}else{
			$end[0] = $end['day'];
			$end[1] = $end['month'];
			$end[2] = $end['year'];
		}
		
		$month_start_day =	mktime(0,0,0,$start[1],$start[0],$start[2]);// mktime(...thang, ngay, nam)
		$month_end_day =	mktime(0,0,0,$end[1],$end[0],$end[2]);

		$estart = explode('-', $event_day[0]);
		$eend = explode('-', $event_day[1]);
		
		$event_start_day =	mktime(0,0,0,$estart[1],$estart[0],$estart[2]); // mktime(...thang, ngay, nam)
		$event_end_day =	mktime(0,0,0,$eend[1],$eend[0],$eend[2]);

		$rs = array();
		if($event_start_day<=$month_start_day && $event_end_day>=$month_end_day){
			for($i=1;$i<=31;$i++){
				$rs[] = $i;
			}
		}elseif($event_start_day<=$month_start_day && $event_end_day<=$month_end_day){
			for($i=1;$i<=$eend[0];$i++){
				$rs[] = $i;
			}
		}elseif($event_start_day>=$month_start_day && $event_end_day>=$month_end_day){
			for($i=$estart[0];$i<=$end[0];$i++){
				$rs[] = $i;
			}
		}elseif($event_start_day>=$month_start_day && $event_end_day<=$month_end_day){
			for($i=$estart[0];$i<=$eend[0];$i++){
				$rs[] = $i;
			}
		}
		return $rs;
	}

 	function view()
 	{
 		global $mainframe;
 		$view = $this->getView('event', 'html');
 		$event_Id =& JRequest::getVar('event', '', 'get', 'int');
 		
 		$config = $this->getModel('config');
 		$GLOBALS['agenda_config'] = $config;
 		 		
 		$event = $this->getModel('event');
 		$event_detail = $event->loadEvent($event_Id);
 		
 		$other_events = $event->loadEventCat($event_detail->cat_id);
 		
 		$view->assignRef('event_details', $event_detail);
 		$view->assignRef('agenda_config', $config);
 		$view->assignRef('other_events', $other_events);
 		$view->display();
 	}
 	
 	function search()
 	{
 		$v = JRequest::getVar('layout','');
 		if($v=='advance'){
	 		$view = $this->getView('search', 'html');
	 		$view->display('advance');
 		}else{	
	 		$view = $this->getView('search', 'html');
	 		
	 		$config = $this->getModel('config');
	 		$GLOBALS['agenda_config'] = $config;
	 		$model = $this->getModel('event');
	 		
	 		$key = JRequest::getVar('keyword', '', 'POST');
	 		$advance = JRequest::getVar('advance', 0, 'post');
	 		
	 		$view->assignRef('result', $model->searchKeyword($key, $advance, $_POST));
	 		$view->assign('date_format', $config->get('date_format', 'value'));
	 		$view->display();
 		}
 	}
 	
 	function listevent()
 	{
 		$cat = JRequest::getVar('cat', '', 'get', 'int');
 		
 		$config = $this->getModel('config');
 		$GLOBALS['agenda_config'] = $config;
 		 		
 		$event = $this->getModel('event');
	
 		$view = $this->getView('event', 'html');

		$unk = $event->getChilds($cat);
		if(count($unk)>=1)
		{
			$view->assignRef('cat_info', $event->loadCat($cat));
			$view->assignRef('cats', $unk);
	 		$view->assignRef('events', $event->loadEventCat($cat));
			$view->display('table');
			return;
		}
 		$view->assignRef('cat_info', $event->loadCat($cat));
 		$view->assignRef('events', $event->loadEventCat($cat));
 		$view->display('category');
 	}
 }
?>
