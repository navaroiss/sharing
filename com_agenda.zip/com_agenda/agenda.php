<?php
/*
 * $Id: Jul 4, 2009 4:29:07 PM navaro  $
 *  
 */
 include( JPATH_COMPONENT.DS. 'controller.php');
 
 $lang =& JFactory::getLanguage();
 $lang->load('com_agenda', JPATH_COMPONENT);
 
 $controller = new AgendaController();
 $controller->execute( JRequest::getCmd('task', 'calendar') );
?>