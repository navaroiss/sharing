<?php
/*
 * $Id: Jul 4, 2009 4:37:40 PM navaro  $
 *  
 */
 jimport('joomla.application.component.view');
 class AgendaViewCalendar extends JView 
 {
 	function display($tmp = null)
 	{
 		$doc =& JFactory::getDocument();
		$doc->addStyleSheet(JURI::root().'components/com_agenda/assets/css/agenda.calendar.css');
		$border_width = $this->agenda_config->get('border_width','value');
		$border_color = $this->agenda_config->get('border_color','value');
		$width_calendar = $this->agenda_config->get('width_calendar','value');
		$height_calendar = $this->agenda_config->get('height_calendar','value');
		$width_cell = $this->agenda_config->get('width_cell','value');
		$height_cell = $this->agenda_config->get('height_cell','value');
		$font_color = $this->agenda_config->get('font_color','value');
		$font_size = $this->agenda_config->get('font_size','value');
		$calendar_css = $this->agenda_config->get('calendar_css','value');
 		$css = "
		table#calendar{
		border: $border_width solid $border_color;
		width: $width_calendar;
		height: $height_calendar;
		}
		table#calendar td{
		width: $width_cell;
		height:$height_cell;
		border: $border_width solid $border_color;
		font-color: $font_color;
		font-size: $font_size;
		}
		table#calendar .head{
		font-size: $font_size;
		}
		table#calendar td.prevm:hover,  table#calendar td.normal:hover,  table#calendar td.event:hover{
		border: $border_width solid $border_color;
		}
		table#calendar .today{
		font-size: $font_size;
		}";
 		$doc->addStyleDeclaration($css);
 		$doc->addScript( JURI::root().'components/com_agenda/assets/js/jquery-1.3.2.min.js');
 		$doc->addScript( JURI::root().'components/com_agenda/assets/js/tooltip.js');
 		$doc->addScript( JURI::root().'components/com_agenda/assets/js/behavior.js');
 		
 		$doc->addStyleSheet(JURI::root().'/administrator/components/com_congres/css/cardio/jquery-ui-1.7.custom.css');
 		$doc->addStyleSheet(JURI::root().'/administrator/components/com_congres/css/congres.css');
 		$doc->addScript( JURI::root().'administrator/components/com_congres/js/jquery-ui-1.7.2.custom.min.js');
 		
		// ADD custom css
		$doc->addStyleDeclaration($calendar_css);
 		parent::display($tmp);
 	}
 }
?>