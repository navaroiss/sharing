<?php
/*
 * $Id: Jul 4, 2009 4:38:00 PM navaro  $
 *  
 */
	include(dirname(__FILE__).DS.'_basic.php');
	global $mainframe;
?>
<style type="text/css">
.top_line_agenda{
	padding-top:5px;
}
</style>
<!--[if IE 6]>
<style type="text/css">
#header-bar{
	width:959px;
}
</style>
<![endif]-->
<!--[if lt IE 8]>
<style type="text/css">

table#topline td{
	padding-left:15px;
}

.top_line_agenda{
	padding-top:-5px;
}
table#blueline{
	width: 923px;
}
table#blueline td.line1{
	width: 360px;
	text-align:left;
	float:left;
}
table#blueline td.line2{
	width: 330px;
	text-align:center;
}
table#blueline td.line3{
	width: 330px;
	text-align:right;
	float:right;
}
table#blueline .line{
	height:3px;
}
#cbx{
	margin-left:130px;
}
#cbx_td_right{
	text-align:right;
	padding-right:0px;
	float:right;
	padding-left:300px;
}

</style>
<![endif]-->

<div class="component-header">
	<table id="topline" class="componentheading" width="100%">
		<tr>
			<td valign="top">
				<span><?=JText::_('AGENDA')?></span>
			</td>
			<td valign="top" align="right" style="font-weight:normal">
				<a href="#FILTER"><?php echo JText::_('FILTER')?></a>&nbsp;&nbsp;&nbsp; <a href="#ADSEARCH"><?php echo JText::_('ADVANCE FIND')?></a>&nbsp;&nbsp;
			</td>
		</tr>
	</table>
<!--  <div class="componentheading" style="float:left"></div>-->	
</div>
<br style="clear:all"/>

<script type="text/javascript">
function changeURL()
{
	month = document.f1.month.value;
	year = document.f1.year.value;
	document.location = "<?echo $url?>"+"&month="+month + "&year="+ year+ "&Itemid=" + <?=$Itemid?>+ "&lang=<?echo $lang?>" 
}
	
var content = new Array();
var cat_items = new Array();
<?php
	$cat_items = array(); 
	if(count($this->other_events)>=1)
	{
		if(count($this->other_events['prev']['event'])>=1)
		{
			foreach($this->other_events['prev']['title'] as $k=>$v)
			{
				?>
				content['1000<?php echo $k?>'] = '<?php echo addslashes($v);?>'; 
				<?
			}
			if(count($this->other_events['prev']['cid'])>=1)
			{
				foreach($this->other_events['prev']['cid'] as $k=>$v)
				{
					$cat_items[$v][]=$k;
				}
			}
		}
		if(count($this->other_events['next']['event'])>=1)
		{
			foreach($this->other_events['next']['title'] as $k=>$v)
			{
				?>
				content['2000<?php echo $k?>'] = '<?php echo addslashes($v);?>'; 
				<?
			}
			if(count($this->other_events['next']['cid'])>=1)
			{
				foreach($this->other_events['next']['cid'] as $k=>$v)
				{
					$cat_items[$v][]=$k;
				}
			}
		}
	}
	if(count($this->events)>=1){
		if( count($this->events['title'])>=1 ){
			foreach($this->events['title'] as $k=>$v)
			{ 
				?>
				content['<?php echo $k?>'] = '<?php echo addslashes($v);?>'; 
				<?
			}
			if(count($this->events['cat'])>=1)
			{
				foreach($this->events['cat'] as $k=>$v)
				{
					$cat_items[$v][]=$k;
				}
			}
		}
	}
	//print_r($this->other_events['prev']);
?>
</script>

<table width="100%" id="calendar" border="1">
<tr>
	<td class="head" colspan="7">
		<form name="f1" action="<?php echo JURI::root().$url."task=search"?>" method="post">
	<table width="100%">
		<tr>
		<td width="365" height="20" align="left" class="tdhead" valign="top" style="height: 20px;">
			<input type="text" style="width: 230px;" name="keyword" onfocus="this.value=''" onblur="if (this.value=='') {this.value='<?php echo JTEXT::_('FIND')?>...'}" value="<?php echo JTEXT::_('FIND')?>..." />
			<input type="hidden" name="Itemid" value="<?php echo $Itemid?>">
			<input type="submit" name="sm" class="hide">
		</td>
		<td width="auto" height="20" align="center" class="tdhead ltie8" valign="top" style="height: 20px;">
		<table height="20" id="cbx" style="height:20px">
			<td height="20" style="height:20px;width:15px" align="left"><a href="<?php echo $url."month=".$prev['month']."&year=".$py?>&Itemid=<?php echo $Itemid;?>&lang=<?php echo $lang?>"><<</a></td>
			<td height="20" style="height:20px;width:100px" align="left">
				<select name="month" onchange="javascript:changeURL()">
					<?
						$i=1;
						foreach($month_array as $k=>$v)
						{
							$s = '';
							if($i==$month){
								$s = "selected='selected'";
							}
						 ?>
						 <option <? echo $s ?> value="<? echo $i ?>"><? echo JText::_($v); ?></option>
						 <?
						 $i++;
						}
					 ?>
				</select>
			</td>
			<td height="20" style="height:20px;width:50px" align="left">
				<select name="year" onchange="javascript:changeURL()">
					<?
						$year_start = 2008;
						for($i=$year_start;$i<=$year_start+10;$i++)
						{
						 $s = ($i==$year)?"selected='selected'":'';
						 ?>
						 <option <? echo $s ?> value="<? echo $i ?>"><? echo $i; ?></option>
						 <?
						}
					 ?>
				</select>
			</td>
			<td height="20" style="height:20px" align="left">
				<a href="<?php echo $url."month=".$next['month']."&year=".$ny?>&Itemid=<?php echo $Itemid;?>&lang=<?php echo $lang?>">>></a>
			</td>
		</table>
		</td>
		<td width="365" height="20" style="height: 20px;" align="right" class="tdhead" id="cbx_td_right" valign="top">
		<a href="<?php echo $url."month=".date('m')."&year=".date('Y')."&Itemid=$Itemid&lang=$lang"?>"><? echo JText::_(TODAY) ?></a>
		</td>
		</tr>
	</table>
		</form>
		<!-- 
	<div class="float_left mar5">
		<a class="adv_find" href="index.php?option=com_agenda&task=search&layout=advance"><?php echo JTEXT::_('ADVANCE FIND')?></a>
		<a href="<?php echo $url."year=".$prev['year']?>">&laquo;</a>&nbsp;&nbsp;&nbsp; 
		<a href="<?php echo $url."month=".$prev['month']."&year=".$py?>">&lang;</a>&nbsp;&nbsp;&nbsp;
		<?php 
			echo JTEXT::_(TODAY);
			$date = date($this->agenda_config->get('date_format','value'), time());
			
			foreach(explode(' ', $date) as $k=>$v)
			{
				if(preg_match('/(.*),/', $v, $m)){
					echo " ".strtolower(JTEXT::_( str_replace(',','',$v) )).", ";	
				}else{
					echo " ".JTEXT::_( $v );
				}
			}
		?>&nbsp;&nbsp;&nbsp;
		<a href="<?php echo $url."month=".$next['month']."&year=".$ny?>">&rang;</a>&nbsp;&nbsp;&nbsp;
		<a href="<?php echo $url."year=".$next['year']?>">&raquo;</a>&nbsp;&nbsp;&nbsp;
	</div>
	 -->
	</td>
</tr>
<tr>
	<td colspan="7" style="height:50px" width="923">
		<table width="100%" id="blueline" class="blueline">
			<tr>
				<td style="height: 40px; text-align: left;" align="left" class="line1">
					<hr align="left" class="line" color="#34568E" />
				</td>
				<td width="300" style="height: 40px;" align="center" class="line2">
					<font size="5"><?php echo JText::_($month_array[$month-1]).' '.$year?></font>
				</td>
				<td style="height: 40px; text-align: right;" align="right" class="line3">
					<hr align="right" class="line" color="#34568E" />
				</td>
			</tr>
		</table>
	</td>
</tr>
<!-- 
<tr>
	<?php 
		foreach($w as $k=>$d)
		{
			echo "<td class='head'>".JTEXT::_($d)."</td>";
			if($d==$first_d) $n = $a;
			$a++; 
		}
	?>
</tr>
-->
<?php


function getCategoryID($store=array(), $event_id=0)
{
	foreach($store as $k=>$v)
	{
		foreach($v as $k1=>$v1)
		{
			if($v1==$event_id)
			{
				return "cat$k";
			}
		}
	}
}
function getEvent($day, $events, $url, $lang, $icon_path, $s='', $cat_items)
{
	global $Itemid;
	$content='';
	
	if($s==''){
		if(count($events['event'])>=1){
			foreach($events['event'] as $k=>$vl){
				if( in_array($day, $vl) ){
					$content .= "<a href='".$url."task=view&event=".$k."&Itemid=".$Itemid."&lang=$lang'>
									<img id='".$k."' class='tickevent ".getCategoryID($cat_items, $k)."' src='".JURI::root().$icon_path.$events['icon'][$k]."' /></a>";
				}
			}
		}
	}
	if($s=='-')
	{
		if(count($events['event'])>=1){
			foreach($events['event'] as $k=>$vl){
				if( in_array($day, $vl) ){
					$content .= "<a href='".$url."task=view&event=".$k."&Itemid=".$Itemid."&lang=$lang'>
									<img id='1000".$k."' class='tickevent ".getCategoryID($cat_items, $k)."' src='".JURI::root().$icon_path.$events['icon'][$k]."' /></a>";
				}
			}
		}
	}
	if($s=='+')
	{
		if(count($events['event'])>=1){
			foreach($events['event'] as $k=>$vl){
				if( in_array($day, $vl) ){
					$content .= "<a href='".$url."task=view&event=".$k."&Itemid=".$Itemid."&lang=$lang'>
									<img id='2000".$k."' class='tickevent ".getCategoryID($cat_items, $k)."' src='".JURI::root().$icon_path.$events['icon'][$k]."' /></a>";
				}
			}
		}
	}
	return $content;
}

$full_row = 0;
for($i=1;$i<=$month_days+$n;$i++)
{
	if($i-$n<=0)
		$tdcss = 'prevm';
	elseif($i-$n==$today && $current_month == $month)
		$tdcss = 'today';
	else
		$tdcss = 'normal';
	
	$ngay = ($i-$n)<=0?$i-$n+$month_days_prev:$i-$n;
	
	if(($i-$n)<=0){
		if( count($this->other_events['prev'])>=1 ){
			$content = getEvent($i-$n+$month_days_prev, $this->other_events['prev'], $url, $lang, $this->icon_path, '-', $cat_items);
		}
	}else{
		if( count($this->events['event'])>=1 ){
			$content = getEvent($i-$n, $this->events, $url, $lang, $this->icon_path,"", $cat_items);
		}
	}
	print sprintf($shtml, $tdcss, JText::_(strtoupper($w[$full_row])).' '.$ngay, $content);
	
	if($i%7==0 && $i<$month_days+$n) {
		echo "<tr>";
		$full_row = 0;
	}else{
		$full_row++;
	}
}
//print_r($this->other_events['next']);
if($full_row>=1){
	for($i=1;$i<=7-$full_row;$i++){
		$content = '';
		if( count($this->other_events['next'])>=1 ){
			$content = getEvent($i, $this->other_events['next'], $url, $lang, $this->icon_path, '+', $cat_items);
		}
		print sprintf($shtml, 'nextm', JText::_(strtoupper($w[$full_row+$i-1])).' '.$i, $content);
	}
}

?>
</table>

<div align="center"></div>
      <div class="portlet ui-widget ui-widget-content ui-helper-clearfix ui-corner-all agendawidth">
      <div id="click-bt" class="portlet-header clickable ui-widget-header-blue ui-corner-all">
		<?php 
			echo JTEXT::_(CLICK_EVENT);
		?>&nbsp;&nbsp;&nbsp;
      </div>
      <div class="portlet-content">
		<table id="table-list-event">
			<?php
			for($i=1;$i<=$month_days;$i++)
			{
				$c=0;
				foreach($this->events['event'] as $k=>$v)
				{
					if(in_array($i, $v))
					{	
						$c++;
						?>
						<tr>
							<?php 
								if($c==1){ 
									echo "<td class='list-date' align='right'>$i-$month-$year:</td>"; 
								}else{
									echo "<td></td>";
								}
							?>
							<td>
								<img id='<?php echo $k?>' class='tickevent <?php echo getCategoryID($cat_items, $k)?>' src='<?php echo JURI::root().$this->icon_path.$this->events['icon'][$k]?>' />
								<a href="index.php?option=com_agenda&task=view&event=<?php echo $k?>&Itemid=<?php echo $Itemid?>&lang=<?php echo $lang;?>">
									<?php echo $this->events['title'][$k]?>
								</a>
							</td>
						</tr>
						<?
					}
				}
			}
			?>
			</table>
	      </div>
      </div>
      
<?php
if(count($this->events['event']>=1)){
	?>
	
	<?php 
}
	jimport( 'joomla.application.module.helper' );
	$module_user =& JModuleHelper::getModule('mod_agenda_user', "Agenda - The Filter");
	$module_adsearch =& JModuleHelper::getModule('mod_agenda_adsearch', "Recherche advancee");
	$attribs['style'] = 'xhtml';
?>
<div>
	<table id="mod_bottom" width="99%" align="left" cellspacing="5" cellpadding="5">
		<tr>
			<td width="33%" valign="top" id="FILTER">
		      <div class="portlet ui-widget ui-widget-content ui-helper-clearfix ui-corner-all">
			      <div class="portlet-header clickable ui-widget-header-blue ui-corner-all"><?=JText::_("FILTER")?></div>
			      <div class="portlet-content">
			       <? echo JModuleHelper::renderModule($module_user, $attribs);?>
			      </div>
		      </div>
			</td>
			<td width="33%" valign="top" id="ADSEARCH">
			<div class="h230px portlet ui-widget ui-widget-content ui-helper-clearfix ui-corner-all">
		      <div class="portlet-header clickable ui-widget-header-blue ui-corner-all"><?=JText::_("ADVANCE FIND")?></div>
		      <div class="portlet-content">
		       <? echo JModuleHelper::renderModule($module_adsearch, $attribs);?>
		      </div>
		     </div>
			</td>
			<td width="33%" valign="top">
			<div class="h230px portlet ui-widget ui-widget-content ui-helper-clearfix ui-corner-all">
		      <div class="portlet-header clickable ui-widget-header-blue ui-corner-all"><?=JText::_("ENQUETES")?></div>
		      <div class="portlet-content">
				<?php 
					$db =& JFactory::getDBO();
					$db->setQuery("select * from #__modules where id in (select `value` from #__agenda_config where name='mod_apoll_id')");
					$result = $db->loadObject();
					echo JModuleHelper::renderModule($result, $attribs);
				?>
			  </div>
		    </div>
			</td>
		</tr>
	</table>
</div>

