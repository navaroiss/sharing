<?php
/*
 * $Id: Jul 8, 2009 1:54:29 PM navaro  $
 * print_r($this->event_details); 
 */
 //print_r($this->event_details );
 ?>
<div class="component-header"> <h1 class="componentheading" style="visibility: visible;"><span><?=JText::_('AGENDA')?></span> </h1></div>

 
<div id="event_title">
	<div class="float_left" style="margin-top: 10px;">
		<?php echo stripslashes($this->event_details->title)?>
	</div>
	<div class="float_right">
	<? if($this->event_details->c_icon!=''){?>
		<img src="<?php echo JURI::root().$this->agenda_config->get('icon_path', 'value').$this->event_details->c_icon?>" />
	<? } ?>
	</div>
</div>
<div id="event_content">
	<table width="100%">
	<tr>
		<td valign="top">
			<p>		
				<?php echo $this->event_details->description?>
			</p>
			<p>
				<?php echo $this->event_details->content?>
			</p>
		</td>
		<td width="20%" valign="top">
		<?php 
		if(count($this->other_events)>=1){
			global $Itemid;
			echo '<b style="margin-top:0px;font-size:14px;">'.JText::_('OTHER EVENTS').'</b>';
			$lang =& JRequest::getVar('lang','');
			foreach($this->other_events as $k=>$v)
			{
				if($v->id != $this->event_details->id)
				{
				?>
					<div>
						<?php echo date('d-m-Y', strtotime($v->start_date))?>: <a href='<?=JURI::root()?>index.php?option=com_agenda&task=view&event=<?=$v->id?>&lang=<?=$lang?>&Itemid=<?=$Itemid?>'><?=$v->title?></a>	
					</div>
				<?
				}
			}
		}
		?>
		</td>
	</tr>
	</table>
</div>
<img style="cursor: pointer;" onclick="javascript:history.back(-1)" height="16" width="20" src="<?php echo JURI::root().'components/com_agenda/assets/images/arrow-back.png'?>"/>
