<?php
/*
 * $Id: Jul 11, 2009 12:16:19 AM navaro  $
 *  
 */
 global $Itemid;
?>
<div class="component-header"> <h1 class="componentheading" style="visibility: visible;"><span><?=JText::_('AGENDA')?></span> </h1></div>

<form method="POST" name="moteur_de_recherche" action="index.php?option=com_agenda&task=search">
<input type="hidden" name="advance" value="1">
<input type="hidden" name="Itemid" value="<?=$Itemid?>">
<table>
<tr>
<td align="left">
<?php echo JTEXT::_('KEYWORD')?> <input type="text" maxlength="50" size="17" name="keyword"/>
</td>
</tr>
<tr>
<td align="left">
<?php echo JTEXT::_('FMC')?> <input type="checkbox" value="1" name="fmc"/>
</td>
</tr>
<tr>
<td align="left">
<?php echo JTEXT::_('FROM')?>&nbsp;
<?php 
	$m = array(
		'01'=>'JANUARY',
		'02'=>'FEBRUARY',
		'03'=>'MARCH',
		'04'=>'APRIL',
		'05'=>'MAY',
		'06'=>'JUNE',
		'07'=>'JULY',
		'08'=>'AUGUST',
		'09'=>'SEPTEMBER',
		'10'=>'OCTOBER',
		'11'=>'NOVEMBER',
		'12'=>'DECEMBER',
	);
	$y = array(2007,2008,2009,2010,2011,2012,2013,2014,2015);
?>
<select name="from_month" class="myselect">
  <?php 
  	foreach($m as $k=>$v)
  	{
  		$s = ($k==date('m'))?'selected="selected"':'';
  	?>
  		<option <?php echo $s?> value="<?php echo $k?>"><?php echo JTEXT::_($v)?></option>
  	<?	
  	}
  ?>
 </select>
  &nbsp;
<select name="from_year" class="myselect">
  <?php 
  	foreach($y as $k=>$v)
  	{
  		$s = ($v==date('Y'))?'selected="selected"':'';
  	?>
  		<option <?php echo $s?> value="<?php echo $v?>"><?php echo $v?></option>
  	<?	
  	}
  ?>
 </select>
</td>
</tr>
<tr>
<td align="left">
<?php echo JTEXT::_('TO')?> &nbsp;
<select name="to_month" class="myselect">
  <?php 
  	foreach($m as $k=>$v)
  	{
  		$s = ($k==date('m'))?'selected="selected"':'';
  	?>
  		<option <?php echo $s?> value="<?php echo $k?>"><?php echo JTEXT::_($v)?></option>
  	<?	
  	}
  ?>
 </select>
&nbsp;
<select name="to_year" class="myselect">
  <?php 
  	foreach($y as $k=>$v)
  	{
  		$s = ($v==date('Y'))?'selected="selected"':'';
  	?>
  		<option <?php echo $s?> value="<?php echo $v?>"><?php echo $v?></option>
  	<?	
  	}
  ?>
 </select>
</td>
</tr>
<tr>
	<td align="left"><input type="submit" value="<?php echo JTEXT::_('FIND')?>"/></td>
</tr>
</table>
</form>
