<?php
/*
 * $Id: Jul 9, 2009 2:13:00 AM navaro  $
 *  
 */

 global $Itemid;
 if(count($this->result)>=1){
?>
 <div class="component-header"> <h1 class="componentheading" style="visibility: visible;"><span><?=JText::_('AGENDA')?></span> </h1></div>
 
<?php echo JText::_('EVENTS')?>:
<hr/>
<table width="100%" cellpadding="0" cellspacing="0">
<? 
 foreach($this->result as $k=>$v)
 {
 ?>
 	<tr>
 		<td>
		<?=date('d M Y', strtotime($v->start_date))?>
		- 
 		<a class="a_underline" href="<?php echo "index.php?option=com_agenda&task=view&event={$v->id}&Itemid={$Itemid}"?>">
 			<?php echo stripcslashes($v->name." - ".$v->title)?>
 		</a>

 		</td>
 	</tr>
 <?	
 }
?>
</table>
<? }else{ echo JText::_('NORESULT'); } ?>
