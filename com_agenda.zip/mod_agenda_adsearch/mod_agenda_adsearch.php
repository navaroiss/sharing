<?php

	 include(JModuleHelper::getLayoutPath('mod_agenda_adsearch'));

?>