<?php
/*
 * $Id: Jul 9, 2009 4:22:06 PM navaro  $
 *
 */
include(dirname(__FILE__).DS.'traverse.php');
class AdvanceTvs extends Traverse
{
	var $_sync_data = null;
	function AdvanceTvs($sql_resource, $result_sync, $icon_path, $parent='parent', $id='id')
	{
		$this->_sql_resource = $sql_resource;
		$this->_sync_data = $result_sync;
		$this->_parent = $parent;
		$this->_id = $id;
		$this->_space = '&nbsp;&nbsp;';
		$this->_icon_path = $icon_path;
		global $Itemid;
		$this->_itemid = $Itemid;
		$this->_lang = JRequest::getVar('lang',''); 
	}

	function getDropDownList($item_selecteds=0, $r=0, $d=0, $parent_sign='')
	{
		$row = 0;
		while($data = mysql_fetch_array($this->_sql_resource))
		{
			$data_name = $this->getDataName($data[$this->_id]);
			if($data[$this->_parent] == $r)
			{
				if(is_array($item_selecteds)){
					$s = in_array($data[$this->_id], $item_selecteds)?'class="checked"':'';
					$c = in_array($data[$this->_id], $item_selecteds)?'checked="checked"':''; 
				}else{
					$s = ($item_selecteds==$data[$this->_id])?'class="checked" checked="checked"':'';
					$c = ($item_selecteds==$data[$this->_id])?'checked="checked"':'';
				}

				$t .= '<li><input '.$c.' type="checkbox" name="id[]" value="'.$data[$this->_id].'">';
				$t .= '<label '.$s.'>'."<a class='cats_img' href='index.php?option=com_agenda&task=listevent&cat=".$data[$this->_id]."&Itemid=".$this->_itemid."&lang=".$this->_lang."'>".$this->_space."<img src='".JURI::root().$this->_icon_path.$data['icon']."'/></a>".$this->_space.$data_name;
				$t .= '</label>';
				
				$t .= "<ul>";
				
				@mysql_data_seek($this->_sql_resource, 0);
				$t .= $this->getDropDownList($item_selecteds, $data['id'], $d+1, $sign);
				
				$t .= '</ul></li>';	
			}
			$row++;
			@mysql_data_seek($this->_sql_resource, $row);
						
		}
		return $t;
	}

	function getDataName($data_id)
	{
		foreach($this->_sync_data as $k=>$v)
		{
			if($v->id == $data_id)
			{
				return $v->name;
			}
		}
	}
}
?>