<?php
/*
 * $Id: Jul 10, 2009 1:08:23 AM navaro  $
 *
 */
class Traverse
{
	var $_sql_resource = null;
	var $_parent = '';
	var $_id = '';
	var $_space = "&nbsp;&nbsp;";

	function Traverse($sql_resource, $parent='parent', $id='id')
	{
		$this->_sql_resource = $sql_resource;
		$this->_parent = $parent;
		$this->_id = $id;
	}

	function getBasicComboBox($item_selecteds=0, $r=0, $d=0)
	{
		$row = 0;
		while($data = mysql_fetch_array($this->_sql_resource))
		{
			if($data[$this->_parent] == $r)
			{
				if(is_array($item_selecteds)){
					$s = in_array($data[$this->_id], $item_selecteds)?'selected="selected"':'';
				}else{
					$s = ($item_selecteds==$data[$this->_id])?'selected="selected"':'';
				}
				$t .= "<option value='" . $data[$this->_id] . "' $s>";
				$j=0;
				while($j<$d)
				{
					$t .= $this->_space;
					$j++;
				}
				$t .= $data['name']."</option>";
				@mysql_data_seek($this->_sql_resource, 0);
				$t .= $this->getBasicComboBox($item_selecteds, $data['id'], $d+1);
			}
			$row++;
			@mysql_data_seek($this->_sql_resource, $row);
		}
		return $t;
	}

	function getBasicCheckbox($item_selecteds=0, $r=0, $d=0)
	{
		$row = 0;
		while($data = mysql_fetch_array($this->_sql_resource))
		{
			if($data[$this->_parent] == $r)
			{
				if(is_array($item_selecteds)){
					$s = in_array($data[$this->_id], $item_selecteds)?'checked="checked"':'';
				}else{
					$s = ($item_selecteds==$data[$this->_id])?'checked="checked"':'';
				}
				$t .= "<div><input id='item_{$data[$this->_id]}' type='checkbox' name='{$this->_id}[]' value='".$data[$this->_id]."' $s>";
				$j=0;
				while($j<$d)
				{
					$t .= $this->_space;
					$j++;
				}
				$t .= "<label for='item_{$data[$this->_id]}'>".$data['name']."</label></div>";
				@mysql_data_seek($this->_sql_resource, 0);
				$t .= $this->getBasicCheckbox($item_selecteds, $data['id'], $d+1);
			}
			$row++;
			@mysql_data_seek($this->_sql_resource, $row);
		}
		return $t;
	}
}
?>